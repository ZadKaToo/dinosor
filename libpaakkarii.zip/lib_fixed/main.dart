import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'state/app_state.dart';
import 'screens/login_screen.dart'; // ✅ นำเข้า LoginScreen เป็นหน้าแรก

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'https://fvccmpvjvahvoqglfizt.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZ2Y2NtcHZqdmFodm9xZ2xmaXp0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY2ODc3NjcsImV4cCI6MjEwMjI2Mzc2N30.3E6y4EETGMWGATTsXGW_yhx3VdlzOSLpnWZc2Hfi6tY',
  );

  runApp(
    ChangeNotifierProvider(
      create: (_) => AppState(),
      child: const LearnProApp(),
    ),
  );
}

class LearnProApp extends StatelessWidget {
  const LearnProApp({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return MaterialApp(
      title: 'LearnPro MAX — IT Career Platform',
      debugShowCheckedModeBanner: false,
      theme: state.themeData,
      home: const LoginScreen(), // ✅ เปลี่ยนจาก MainLayoutScreen เป็น LoginScreen
    );
  }
}