class ChatSessionModel {
  final String id;
  final String userId;
  final String sessionType;
  final String? title;

  ChatSessionModel({required this.id, required this.userId, this.sessionType = 'career_advice', this.title});

  factory ChatSessionModel.fromJson(Map<String, dynamic> json) => ChatSessionModel(
    id: json['id'], userId: json['user_id'], sessionType: json['session_type'] ?? 'career_advice', title: json['title'],
  );
}

class ChatMessageModel {
  final String id;
  final String sessionId;
  final String senderType; // 'user' or 'ai'
  final String messageText;
  final DateTime? createdAt;

  ChatMessageModel({required this.id, required this.sessionId, required this.senderType, required this.messageText, this.createdAt});

  factory ChatMessageModel.fromJson(Map<String, dynamic> json) => ChatMessageModel(
    id: json['id'], sessionId: json['session_id'], senderType: json['sender_type'], messageText: json['message_text'],
    createdAt: json['created_at'] != null ? DateTime.parse(json['created_at']) : null,
  );
}