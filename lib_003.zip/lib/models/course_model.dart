class CourseModel {
  final String id;
  final String title;
  final String? category;
  final String? summary;
  final String? coverImageUrl;
  final String? durationText;
  final String? difficultyLevel;
  final double rating;
  final String? instructor;
  final String? badgeEarned;
  final int totalLessons;
  final int likeCount;
  final int shareCount;

  CourseModel({
    required this.id, required this.title, this.category, this.summary, 
    this.coverImageUrl, this.durationText, this.difficultyLevel, 
    this.rating = 5.0, this.instructor, this.badgeEarned, 
    this.totalLessons = 1, this.likeCount = 0, this.shareCount = 0,
  });

  factory CourseModel.fromJson(Map<String, dynamic> json) => CourseModel(
    id: json['id'], title: json['title'], category: json['category'], summary: json['summary'],
    coverImageUrl: json['cover_image_url'], durationText: json['duration_text'],
    difficultyLevel: json['difficulty_level'], rating: (json['rating'] ?? 5.0).toDouble(),
    instructor: json['instructor'], badgeEarned: json['badge_earned'],
    totalLessons: json['total_lessons'] ?? 1, likeCount: json['like_count'] ?? 0, shareCount: json['share_count'] ?? 0,
  );
}

class LessonModel {
  final String id;
  final String courseId;
  final String title;
  final String content;
  final int orderIndex;
  final int estimatedReadTimeMins;

  LessonModel({required this.id, required this.courseId, required this.title, required this.content, this.orderIndex = 1, this.estimatedReadTimeMins = 5});

  factory LessonModel.fromJson(Map<String, dynamic> json) => LessonModel(
    id: json['id'], courseId: json['course_id'], title: json['title'], content: json['content'],
    orderIndex: json['order_index'] ?? 1, estimatedReadTimeMins: json['estimated_read_time_mins'] ?? 5,
  );
}

class QuizModel {
  final String id;
  final String courseId;
  final String question;
  final List<String> options;
  final int correctAnswerIndex;
  final String? explanation;

  QuizModel({required this.id, required this.courseId, required this.question, required this.options, required this.correctAnswerIndex, this.explanation});

  factory QuizModel.fromJson(Map<String, dynamic> json) => QuizModel(
    id: json['id'], courseId: json['course_id'], question: json['question'],
    options: [json['option_1'], json['option_2'], json['option_3'], json['option_4']],
    correctAnswerIndex: json['correct_answer_index'], explanation: json['explanation'],
  );
}