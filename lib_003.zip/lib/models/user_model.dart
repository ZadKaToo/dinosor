class UserModel {
  final String id;
  final String email;
  final String fullName;
  final String? avatarUrl;
  final String? targetRole;
  final String jobStatus;
  final int readinessScore;
  final String? bio;
  final String? phone;
  final DateTime? createdAt;

  UserModel({
    required this.id,
    required this.email,
    required this.fullName,
    this.avatarUrl,
    this.targetRole,
    this.jobStatus = 'seeking',
    this.readinessScore = 0,
    this.bio,
    this.phone,
    this.createdAt,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
    id: json['id'],
    email: json['email'],
    fullName: json['full_name'],
    avatarUrl: json['avatar_url'],
    targetRole: json['target_role'],
    jobStatus: json['job_status'] ?? 'seeking',
    readinessScore: json['readiness_score'] ?? 0,
    bio: json['bio'],
    phone: json['phone'],
    createdAt: json['created_at'] != null ? DateTime.parse(json['created_at']) : null,
  );
}

class UserSettingsModel {
  final String userId;
  final bool pushNotifications;
  final bool darkMode;
  final String language;

  UserSettingsModel({required this.userId, this.pushNotifications = true, this.darkMode = false, this.language = 'TH'});

  factory UserSettingsModel.fromJson(Map<String, dynamic> json) => UserSettingsModel(
    userId: json['user_id'],
    pushNotifications: json['push_notifications'] ?? true,
    darkMode: json['dark_mode'] ?? false,
    language: json['language'] ?? 'TH',
  );
}

class UserProgressModel {
  final String userId;
  final int totalXp;
  final int streakDays;
  final int runCount;
  final DateTime? lastActiveDate;

  UserProgressModel({required this.userId, this.totalXp = 20, this.streakDays = 0, this.runCount = 0, this.lastActiveDate});

  factory UserProgressModel.fromJson(Map<String, dynamic> json) => UserProgressModel(
    userId: json['user_id'],
    totalXp: json['total_xp'] ?? 20,
    streakDays: json['streak_days'] ?? 0,
    runCount: json['run_count'] ?? 0,
    lastActiveDate: json['last_active_date'] != null ? DateTime.parse(json['last_active_date']) : null,
  );
}