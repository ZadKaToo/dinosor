class JobModel {
  final String id;
  final String title;
  final String company;
  final String location;
  final double salaryMin;
  final double salaryMax;
  final String? category;
  final String? experience;
  final String? missingSkillRecommendation;

  JobModel({
    required this.id, required this.title, required this.company, required this.location,
    required this.salaryMin, required this.salaryMax, this.category, this.experience, this.missingSkillRecommendation,
  });

  factory JobModel.fromJson(Map<String, dynamic> json) => JobModel(
    id: json['id'], title: json['title'], company: json['company'], location: json['location'],
    salaryMin: (json['salary_min']).toDouble(), salaryMax: (json['salary_max']).toDouble(),
    category: json['category'], experience: json['experience'], missingSkillRecommendation: json['missing_skill_recommendation'],
  );
}

class SkillTagModel {
  final int id;
  final String name;
  final String? category;

  SkillTagModel({required this.id, required this.name, this.category});

  factory SkillTagModel.fromJson(Map<String, dynamic> json) => SkillTagModel(
    id: json['id'], name: json['name'], category: json['category'],
  );
}