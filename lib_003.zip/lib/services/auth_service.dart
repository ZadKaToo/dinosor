import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthService {
  static final SupabaseClient _supabase = Supabase.instance.client;

  /// เข้าสู่ระบบด้วย Supabase Auth
  static Future<String?> login(String email, String password) async {
    try {
      final response = await _supabase.auth.signInWithPassword(
        email: email,
        password: password,
      );
      if (response.session != null) return null; // สำเร็จ
      return 'ไม่พบ Session การเข้าใช้งาน';
    } on AuthException catch (e) {
      debugPrint('Login AuthException: ${e.message}');
      return 'อีเมลหรือรหัสผ่านไม่ถูกต้อง';
    } catch (e) {
      debugPrint('Login Unknown Error: $e');
      return 'เกิดข้อผิดพลาดในการเชื่อมต่อ: $e';
    }
  }

  /// สมัครสมาชิกและบันทึกรหัสผ่านตรงๆ ลงตาราง public.users
  static Future<String?> register(String fullName, String email, String password) async {
    try {
      // 1. สร้าง User ในระบบ Auth ของ Supabase
      final response = await _supabase.auth.signUp(
        email: email,
        password: password,
      );

      final user = response.user;
      if (user != null) {
        // 2. บันทึกข้อมูลเข้าตาราง public.users โดยเก็บรหัสผ่านเป็น Plaintext (ไม่ Hash)
        await _supabase.from('users').upsert({
          'id': user.id,
          'email': email,
          'password': password, // เก็บรหัสผ่านตรงๆ ตามที่กำหนด
          'full_name': fullName,
          'job_status': 'seeking',
          'readiness_score': 0,
        });

        // 3. เริ่มต้นข้อมูล Progress ผู้ใช้
        await _supabase.from('user_progress').upsert({
          'user_id': user.id,
          'total_xp': 20,
          'streak_days': 0,
          'run_count': 0,
        });

        return null; // สมัครสำเร็จ
      }
      return 'ไม่สามารถสร้างบัญชีผู้ใช้ได้ โปรดลองอีกครั้ง';
    } on AuthException catch (e) {
      debugPrint('Register AuthException: ${e.message}');
      if (e.message.contains('User already registered')) {
        return 'อีเมลนี้มีผู้ใช้งานแล้ว';
      }
      return e.message;
    } catch (e) {
      debugPrint('Register Unknown Error: $e');
      return 'เกิดข้อผิดพลาดในการบันทึกข้อมูล: $e';
    }
  }

  /// ออกจากระบบ
  static Future<void> logout() async {
    try {
      await _supabase.auth.signOut();
    } catch (e) {
      debugPrint('Logout Error: $e');
    }
  }
}