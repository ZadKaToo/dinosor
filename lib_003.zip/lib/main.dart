import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'constants/app_constants.dart'; // ดึงค่า URL และ Key มาจากไฟล์นี้
import 'state/app_state.dart';
import 'screens/login_screen.dart';
import 'screens/main_layout_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 1. Initialize Supabase โดยใช้ค่าจาก app_constants.dart
  await Supabase.initialize(
    url: kSupabaseUrl, 
    anonKey: kSupabaseAnonKey,
  );

  runApp(
    ChangeNotifierProvider(
      create: (_) => AppState(),
      child: const LearnProApp(),
    ),
  );
}

class LearnProApp extends StatelessWidget {
  const LearnProApp({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    
    return MaterialApp(
      title: 'LearnPro MAX — IT Career Platform',
      debugShowCheckedModeBanner: false,
      theme: state.themeData, // สมมติว่ามี themeData ใน AppState
      home: const AuthGate(),
    );
  }
}

/// Widget สำหรับตรวจสอบสถานะ Session ของ Supabase (เขียนใหม่ให้เป็น Real-time)
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    // ใช้ StreamBuilder จับตาดูสถานะ Auth ของ Supabase
    return StreamBuilder<AuthState>(
      stream: Supabase.instance.client.auth.onAuthStateChange,
      builder: (context, snapshot) {
        // ระหว่างรอโหลดสถานะ
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        // ตรวจสอบว่ามี Session ค้างอยู่หรือไม่
        final session = snapshot.data?.session;

        // ถ้ามี Session (เคยล็อกอินแล้ว) ให้ไปหน้า Main Layout
        if (session != null) {
          return const MainLayoutScreen();
        }

        // ถ้าไม่มี Session ให้ไปหน้า Login
        return const LoginScreen();
      },
    );
  }
}