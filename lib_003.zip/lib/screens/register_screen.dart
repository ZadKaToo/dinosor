// register_screen.dart (อ้างอิงตาราง users: full_name, target_role)
import 'package:flutter/material.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _roleController = TextEditingController();

  void _handleRegister() {
    // เรียกใช้ AuthService.register และสร้าง record ใน user_settings
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('สมัครสมาชิก')),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          TextField(controller: _nameController, decoration: const InputDecoration(labelText: 'ชื่อ-นามสกุล')),
          TextField(controller: _emailController, decoration: const InputDecoration(labelText: 'อีเมล')),
          TextField(controller: _passwordController, obscureText: true, decoration: const InputDecoration(labelText: 'รหัสผ่าน')),
          TextField(controller: _roleController, decoration: const InputDecoration(labelText: 'เป้าหมายสายงาน (Target Role)')),
          const SizedBox(height: 20),
          ElevatedButton(onPressed: _handleRegister, child: const Text('ยืนยันสมัครสมาชิก')),
        ],
      ),
    );
  }
}