// ai_mentor_chat_screen.dart (อ้างอิงตาราง chat_sessions, chat_messages)
import 'package:flutter/material.dart';

class AiMentorChatScreen extends StatefulWidget {
  const AiMentorChatScreen({super.key});

  @override
  State<AiMentorChatScreen> createState() => _AiMentorChatScreenState();
}

class _AiMentorChatScreenState extends State<AiMentorChatScreen> {
  final _messageController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI Career Mentor')),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: const [
                Align(
                  alignment: Alignment.centerLeft,
                  child: Chip(label: Text('สวัสดีครับ! อยากสอบถามเส้นทางสายงาน Developer ด้านไหนเป็นพิเศษไหมครับ?')),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(child: TextField(controller: _messageController, decoration: const InputDecoration(hintText: 'ถาม AI...'))),
                IconButton(icon: const Icon(Icons.send), onPressed: () {}),
              ],
            ),
          ),
        ],
      ),
    );
  }
}