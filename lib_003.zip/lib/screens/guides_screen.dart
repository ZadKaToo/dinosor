// guides_screen.dart (อ้างอิงตาราง user_guides)
import 'package:flutter/material.dart';

class GuidesScreen extends StatelessWidget {
  const GuidesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('คู่มือแนะแนวสายงาน')),
      body: ListView.builder(
        itemCount: 3,
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
              leading: const Icon(Icons.article),
              title: Text('ロードマップ 2026: วิธีเติบโตในสายงาน Software Engineer'),
              subtitle: const Text('เวลาอ่าน: 5 นาที • อ่านแล้ว 1.2k ครั้ง'),
            ),
          );
        },
      ),
    );
  }
}