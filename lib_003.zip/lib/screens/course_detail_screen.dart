// course_detail_screen.dart (อ้างอิงตาราง course_lessons, user_course_history)
import 'package:flutter/material.dart';

class CourseDetailScreen extends StatelessWidget {
  const CourseDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('รายละเอียดคอร์ส')),
      body: Column(
        children: [
          Container(
            height: 180,
            color: Colors.blueGrey,
            child: const Center(child: Icon(Icons.play_circle_fill, size: 64, color: Colors.white)),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const Text('บทเรียนทั้งหมด', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ListTile(
                  leading: const Icon(Icons.check_circle, color: Colors.green),
                  title: const Text('1. รู้จักกับ Flutter Widget'),
                  subtitle: const Text('5 นาที'),
                  onTap: () {},
                ),
                ListTile(
                  leading: const Icon(Icons.circle_outlined),
                  title: const Text('2. State Management'),
                  subtitle: const Text('10 นาที'),
                  onTap: () {},
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () => Navigator.pushNamed(context, '/quiz'),
                  child: const Text('ทำแบบทดสอบประจำคอร์ส'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}