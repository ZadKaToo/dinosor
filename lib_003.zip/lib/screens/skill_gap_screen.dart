// skill_gap_screen.dart (อ้างอิงตาราง user_skill_gaps, user_certified_skills)
import 'package:flutter/material.dart';

class SkillGapScreen extends StatelessWidget {
  const SkillGapScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('วิเคราะห์ Skill Gap')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          Text('ทักษะที่ขาดสำหรับตำแหน่งเป้าหมาย', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          ListTile(
            leading: Icon(Icons.warning, color: Colors.orange),
            title: Text('Docker & Containerization'),
            subtitle: Text('ความสำคัญ: สูง (Urgency: 85/100)'),
          ),
          Divider(),
          Text('ทักษะที่ได้รับ Certificate แล้ว', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          ListTile(
            leading: Icon(Icons.verified, color: Colors.blue),
            title: Text('Dart Fundamentals'),
            subtitle: Text('ออกโดย SkillUp Thailand'),
          ),
        ],
      ),
    );
  }
}