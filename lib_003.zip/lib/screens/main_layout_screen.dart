import 'package:flutter/material.dart';
import 'dashboard_screen.dart';
import 'course_catalog_screen.dart';
import 'job_board_screen.dart';
import 'ai_mentor_chat_screen.dart';
import 'profile_screen.dart';

class MainLayoutScreen extends StatefulWidget {
  const MainLayoutScreen({super.key});

  @override
  State<MainLayoutScreen> createState() => _MainLayoutScreenState();
}

class _MainLayoutScreenState extends State<MainLayoutScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    DashboardScreen(),
    CourseCatalogScreen(),
    JobBoardScreen(),
    AiMentorChatScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.dashboard), label: 'หน้าแรก'),
          BottomNavigationBarItem(icon: Icon(Icons.school), label: 'คอร์สเรียน'),
          BottomNavigationBarItem(icon: Icon(Icons.work), label: 'หางาน'),
          BottomNavigationBarItem(icon: Icon(Icons.smart_toy), label: 'AI Mentor'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'โปรไฟล์'),
        ],
      ),
    );
  }
}