// quiz_screen.dart (อ้างอิงตาราง quizzes: correct_answer_index, options)
import 'package:flutter/material.dart';

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int? _selectedOption;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('แบบทดสอบวัดความรู้')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('คำถาม: Widget ชนิดใดใช้สำหรับจัดวางแนวตั้ง?', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            ...List.generate(4, (index) {
              final options = ['Row', 'Column', 'Stack', 'Container'];
              return RadioListTile<int>(
                title: Text(options[index]),
                value: index,
                groupValue: _selectedOption,
                onChanged: (val) => setState(() => _selectedOption = val),
              );
            }),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _selectedOption == null ? null : () {},
                child: const Text('ส่งคำตอบ'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}