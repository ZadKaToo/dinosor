// job_board_screen.dart (อ้างอิงตาราง jobs, job_skills)
import 'package:flutter/material.dart';

class JobBoardScreen extends StatelessWidget {
  const JobBoardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ตำแหน่งงาน IT')),
      body: ListView.builder(
        itemCount: 4,
        itemBuilder: (context, index) {
          return Card(
            margin: const EdgeInsets.all(8),
            child: ListTile(
              title: const Text('Mobile Developer (Flutter)'),
              subtitle: const Text('บริษัท Tech Co., Ltd. • 35,000 - 55,000 THB'),
              trailing: const Chip(label: Text('ตรงกับทักษะ 80%')),
            ),
          );
        },
      ),
    );
  }
}