// course_catalog_screen.dart (อ้างอิงตาราง courses, saved_courses)
import 'package:flutter/material.dart';

class CourseCatalogScreen extends StatelessWidget {
  const CourseCatalogScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('คอร์สเรียนทั้งหมด')),
      body: ListView.builder(
        itemCount: 5,
        itemBuilder: (context, index) {
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: ListTile(
              title: Text('Flutter Development 10$index'),
              subtitle: const Text('ระดับ: Beginner | 4 ชั่วโมง'),
              trailing: IconButton(
                icon: const Icon(Icons.bookmark_border),
                onPressed: () {}, // บันทึกลง saved_courses
              ),
              onTap: () => Navigator.pushNamed(context, '/course_detail'),
            ),
          );
        },
      ),
    );
  }
}