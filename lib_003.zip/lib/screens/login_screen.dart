// login_screen.dart (อ้างอิงตาราง users: email, password)
import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  void _handleLogin() {
    // เรียกใช้ AuthService.login(_emailController.text, _passwordController.text)
    Navigator.pushReplacementNamed(context, '/main');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('เข้าสู่ระบบ')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(controller: _emailController, decoration: const InputDecoration(labelText: 'Email')),
            TextField(controller: _passwordController, obscureText: true, decoration: const InputDecoration(labelText: 'Password')),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: _handleLogin, child: const Text('เข้าสู่ระบบ')),
            TextButton(
              onPressed: () => Navigator.pushNamed(context, '/register'),
              child: const Text('ยังไม่มีบัญชี? สมัครสมาชิก'),
            )
          ],
        ),
      ),
    );
  }
}