// profile_screen.dart (อ้างอิงตาราง users, user_badges)
import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('โปรไฟล์ผู้ใช้'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => Navigator.pushNamed(context, '/settings'),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const CircleAvatar(radius: 40, child: Icon(Icons.person, size: 40)),
          const SizedBox(height: 10),
          const Center(child: Text('User Full Name', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
          const Center(child: Text('Target: Mobile Developer', style: TextStyle(color: Colors.grey))),
          const SizedBox(height: 20),
          const Text('เหรียญรางวัลที่ได้รับ (Badges)', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            children: const [
              Chip(avatar: Icon(Icons.play_circle), label: Text('First Run')),
              Chip(avatar: Icon(Icons.terminal), label: Text('Coder')),
              Chip(avatar: Icon(Icons.star), label: Text('First XP')),
            ],
          ),
          const Divider(height: 30),
          ListTile(
            leading: const Icon(Icons.pie_chart),
            title: const Text('ตรวจสอบ Skill Gap'),
            onTap: () => Navigator.pushNamed(context, '/skill_gap'),
          ),
          ListTile(
            leading: const Icon(Icons.menu_book),
            title: const Text('คู่มือแนะแนวทั้งหมด'),
            onTap: () => Navigator.pushNamed(context, '/guides'),
          ),
        ],
      ),
    );
  }
}