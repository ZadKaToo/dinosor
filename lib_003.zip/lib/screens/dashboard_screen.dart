// อ้างอิงตาราง user_progress (total_xp, streak_days) และ users (readiness_score)
import 'package:flutter/material.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Dashboard')),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.bolt, color: Colors.orange),
              title: const Text('Streak Days'),
              trailing: const Text('5 วัน', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
          ),
          Card(
            child: ListTile(
              leading: const Icon(Icons.star, color: Colors.amber),
              title: const Text('Total XP'),
              trailing: const Text('120 XP', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
          ),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('ความพร้อมในสายงาน (Readiness Score)', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 10),
                  LinearProgressIndicator(value: 0.65, minHeight: 10),
                  const SizedBox(height: 5),
                  const Text('65% - พร้อมสำหรับระดับ Junior'),
                ],
              ),
            ),
          ),
          ElevatedButton.icon(
            onPressed: () => Navigator.pushNamed(context, '/sandbox'),
            icon: const Icon(Icons.terminal),
            label: const Text('เข้าสู่ Sandbox ทำภารกิจ'),
          ),
        ],
      ),
    );
  }
}