// settings_screen.dart (อ้างอิงตาราง user_settings: push_notifications, dark_mode, language)
import 'package:flutter/material.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _pushNotifications = true;
  bool _darkMode = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ตั้งค่าระบบ')),
      body: ListView(
        children: [
          SwitchListTile(
            title: const Text('การแจ้งเตือน (Push Notifications)'),
            value: _pushNotifications,
            onChanged: (val) => setState(() => _pushNotifications = val),
          ),
          SwitchListTile(
            title: const Text('โหมดมืด (Dark Mode)'),
            value: _darkMode,
            onChanged: (val) => setState(() => _darkMode = val),
          ),
          ListTile(
            title: const Text('ภาษา (Language)'),
            trailing: const Text('TH'),
            onTap: () {},
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.red),
            title: const Text('ออกจากระบบ', style: TextStyle(color: Colors.red)),
            onTap: () => Navigator.pushReplacementNamed(context, '/login'),
          ),
        ],
      ),
    );
  }
}