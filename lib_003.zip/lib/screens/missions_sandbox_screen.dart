// missions_sandbox_screen.dart (อ้างอิงตาราง missions, user_missions)
import 'package:flutter/material.dart';

class MissionsSandboxScreen extends StatefulWidget {
  const MissionsSandboxScreen({super.key});

  @override
  State<MissionsSandboxScreen> createState() => _MissionsSandboxScreenState();
}

class _MissionsSandboxScreenState extends State<MissionsSandboxScreen> {
  final _codeController = TextEditingController(text: 'def greet(name):\n    print(f"Hello, {name}!")');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Code Sandbox & Missions')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('โจทย์: Greeting Automation Script (+40 XP)', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Expanded(
              child: TextField(
                controller: _codeController,
                maxLines: null,
                expands: true,
                style: const TextStyle(fontFamily: 'monospace'),
                decoration: const InputDecoration(border: OutlineInputBorder(), fillColor: Colors.black12, filled: true),
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {}, // เพิ่ม run_count ใน user_progress
                    icon: const Icon(Icons.play_arrow),
                    label: const Text('รันโค้ด'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}