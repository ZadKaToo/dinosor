import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthService {
  static final SupabaseClient _supabase = Supabase.instance.client;

  /// เข้าสู่ระบบ
  static Future<String?> login(String email, String password) async {
    try {
      final response = await _supabase.auth.signInWithPassword(
        email: email,
        password: password,
      );
      if (response.session != null) return null;
      return 'ไม่พบ Session การเข้าใช้งาน';
    } on AuthException catch (e) {
      debugPrint('Login AuthException: ${e.message}');
      return e.message;
    } catch (e) {
      debugPrint('Login Unknown Error: $e');
      return 'เกิดข้อผิดพลาดในการเชื่อมต่อ: $e';
    }
  }

  /// สมัครสมาชิกและบันทึกลงตาราง users
  static Future<String?> register(String fullName, String email, String password) async {
    try {
      // 1. สร้างบัญชีในระบบ Authentication ของ Supabase
      final response = await _supabase.auth.signUp(
        email: email,
        password: password,
      );

      final user = response.user;
      if (user != null) {
        // 2. บันทึกข้อมูลลงตาราง "users" ใน Database ของคุณ
        await _supabase.from('users').insert({
          'id': user.id,                // ใช้ UUID ตรงกับระบบ Auth
          'email': email,               // อีเมล
          'password_hash': password,    // ค่านี้ตั้งเป็น NON-NULLABLE ไว้จึงต้องส่งไปด้วย
          'full_name': fullName,        // ชื่อ-นามสกุล
          'created_at': DateTime.now().toIso8601String(),
        });

        return null; // สำเร็จ ไม่มี Error
      }
      return 'ไม่สามารถสร้างบัญชีผู้ใช้ได้';
    } on AuthException catch (e) {
      debugPrint('Register AuthException: ${e.message}');
      return e.message;
    } catch (e) {
      debugPrint('Register Unknown Error: $e');
      return 'เกิดข้อผิดพลาดในการบันทึกข้อมูล: $e';
    }
  }

  static Future<void> logout() async {
    await _supabase.auth.signOut();
  }
}