import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/app_state.dart';
import '../widgets/google_fonts_shim.dart';

class AIMentorChatScreen extends StatefulWidget {
  const AIMentorChatScreen({super.key});

  @override
  State<AIMentorChatScreen> createState() => _AIMentorChatScreenState();
}

class _AIMentorChatScreenState extends State<AIMentorChatScreen> {
  final TextEditingController _messageController = TextEditingController();

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return Scaffold(
      backgroundColor: state.bgColor,
      appBar: AppBar(
        backgroundColor: state.sidebarColor,
        elevation: 0,
        title: Text(
          'AI Mentor Chat',
          style: GoogleFonts.prompt(color: state.textPrimary, fontWeight: FontWeight.bold),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: Text(
                'พูดคุยกับ AI Mentor เพื่อขอคำแนะนำเรื่องสายงาน IT',
                style: GoogleFonts.prompt(color: state.textSecondary),
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.all(16),
            color: state.sidebarColor,
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    style: TextStyle(color: state.textPrimary),
                    decoration: InputDecoration(
                      hintText: 'พิมพ์ข้อความถาม AI...',
                      hintStyle: TextStyle(color: state.textMuted),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.send, color: Colors.blue),
                  onPressed: () {
                    _messageController.clear();
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}