import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class JobService {
  static final SupabaseClient _supabase = Supabase.instance.client;

  /// 1. ดึงรายการงานทั้งหมด (สามารถส่ง category หรือ experience ไปกรองได้)
  static Future<List<Map<String, dynamic>>> getJobs({String? category, String? experience}) async {
    try {
      // ดึงข้อมูลจากตาราง jobs
      var query = _supabase.from('jobs').select('*');

      // กรองตามหมวดหมู่ถ้ามีการส่งค่ามา
      if (category != null && category.isNotEmpty) {
        query = query.eq('category', category);
      }
      
      // กรองตามประสบการณ์ถ้ามีการส่งค่ามา
      if (experience != null && experience.isNotEmpty) {
        query = query.eq('experience', experience);
      }

      // เรียงลำดับจากงานที่เพิ่มล่าสุด
      final response = await query.order('created_at', ascending: false);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      debugPrint('Error fetching jobs: $e');
      return [];
    }
  }

  /// 2. ดึงรายละเอียดงาน 1 ตำแหน่ง พร้อม Required Skills (Join Table)
  static Future<Map<String, dynamic>?> getJobDetail(String id) async {
    try {
      final response = await _supabase
          .from('jobs')
          .select('''
            *,
            job_skills (
              skills_tags (
                id,
                name,
                category
              )
            )
          ''')
          .eq('id', id)
          .single(); // ใช้ .single() เพราะค้นหาด้วย Primary Key จะได้ข้อมูล 1 แถวเสมอ

      return response;
    } catch (e) {
      debugPrint('Error fetching job detail: $e');
      return null;
    }
  }
}