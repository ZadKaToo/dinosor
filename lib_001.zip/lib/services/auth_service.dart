import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthService {
  static final SupabaseClient _supabase = Supabase.instance.client;

  /// เข้าสู่ระบบ
  static Future<String?> login(String email, String password) async {
    try {
      final response = await _supabase.auth.signInWithPassword(
        email: email,
        password: password,
      );
      if (response.session != null) return null; // สำเร็จ
      return 'ไม่พบ Session การเข้าใช้งาน';
    } on AuthException catch (e) {
      debugPrint('Login AuthException: ${e.message}');
      return 'อีเมลหรือรหัสผ่านไม่ถูกต้อง';
    } catch (e) {
      debugPrint('Login Unknown Error: $e');
      return 'เกิดข้อผิดพลาดในการเชื่อมต่อ: $e';
    }
  }

  /// สมัครสมาชิกและบันทึกลงตาราง public.users
  ///
  /// หมายเหตุ: ไม่ต้อง hash password เองอีกต่อไป — Supabase Auth เก็บรหัสผ่าน
  /// (hash ด้วย bcrypt) ไว้ใน auth.users ให้แล้วโดยอัตโนมัติตอน signUp()
  /// ถ้ามี trigger handle_new_user() ผูกกับ auth.users อยู่แล้ว (ที่คุยกันไปก่อนหน้า)
  /// โค้ดส่วน insert users/user_progress ด้านล่างนี้จะซ้ำซ้อนกับ trigger — ใช้ upsert
  /// ไว้ก่อนเพื่อกันชนกัน แต่แนะนำให้เลือกทางใดทางหนึ่ง (trigger หรือ manual insert นี้)
  static Future<String?> register(String fullName, String email, String password) async {
    try {
      final response = await _supabase.auth.signUp(
        email: email,
        password: password,
      );

      final user = response.user;
      if (user != null) {
        await _supabase.from('users').upsert({
          'id': user.id,
          'email': email,
          'full_name': fullName,
          'job_status': 'seeking',
          'readiness_score': 0,
        });

        await _supabase.from('user_progress').upsert({
          'user_id': user.id,
          'total_xp': 20,
          'streak_days': 0,
          'run_count': 0,
        });

        return null; // สำเร็จ ไม่มี Error
      }
      return 'ไม่สามารถสร้างบัญชีผู้ใช้ได้ โปรดลองอีกครั้ง';
    } on AuthException catch (e) {
      debugPrint('Register AuthException: ${e.message}');
      if (e.message.contains('User already registered')) {
        return 'อีเมลนี้มีผู้ใช้งานแล้ว';
      }
      return e.message;
    } catch (e) {
      debugPrint('Register Unknown Error: $e');
      return 'เกิดข้อผิดพลาดในการบันทึกข้อมูล: $e';
    }
  }

  /// ออกจากระบบ
  static Future<void> logout() async {
    try {
      await _supabase.auth.signOut();
    } catch (e) {
      debugPrint('Logout Error: $e');
    }
  }

  // me() ถูกลบออก — ใช้ UserService.getMyProfile(userId) แทน เพราะดึงจาก
  // ตาราง public.users ผ่าน Supabase client ตรงๆ ได้อยู่แล้ว ไม่ต้องมี endpoint
  // /api/auth/me แยกต่างหากแบบตอนใช้ Express
}
