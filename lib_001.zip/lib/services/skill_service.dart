import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SkillService {
  static final SupabaseClient _supabase = Supabase.instance.client;

  /// 1. ดึงรายชื่อทักษะทั้งหมด (Master Data) สำหรับให้ผู้ใช้ค้นหาหรือเลือก
  static Future<List<Map<String, dynamic>>> getSkillsTags() async {
    try {
      final response = await _supabase
          .from('skills_tags')
          .select('*')
          .order('name', ascending: true); // เรียงตามตัวอักษรเพื่อความง่ายในการค้นหา

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      debugPrint('Error fetching skills tags: $e');
      return [];
    }
  }

  /// 2. ดึงข้อมูลช่องว่างทักษะ (Skill Gaps) ของผู้ใช้ พร้อมชื่อทักษะ เรียงตามความเร่งด่วน
  static Future<List<Map<String, dynamic>>> getMySkillGaps(String userId) async {
    try {
      // ดึงข้อมูลความเร่งด่วน และ Join กับตาราง skills_tags เพื่อเอาชื่อและหมวดหมู่ทักษะ
      final response = await _supabase
          .from('user_skill_gaps')
          .select('''
            urgency_score,
            skills_tags (
              id,
              name,
              category
            )
          ''')
          .eq('user_id', userId)
          .order('urgency_score', ascending: false); // เรียงจากเร่งด่วนมาก (คะแนนสูง) ไปน้อย

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      debugPrint('Error fetching skill gaps: $e');
      return [];
    }
  }

  /// 3. ดึงใบรับรองทักษะ (Certified Skills / Badges) ที่ผู้ใช้ได้รับแล้ว
  /// หมายเหตุ: อ้างอิงจากตาราง user_certified_skills ใน Schema หลักของคุณ
  static Future<List<Map<String, dynamic>>> getMyCertifiedSkills(String userId) async {
    try {
      final response = await _supabase
          .from('user_certified_skills')
          .select('*')
          .eq('user_id', userId)
          .order('certified_at', ascending: false); // เรียงจากใบรับรองล่าสุดที่ได้รับ

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      debugPrint('Error fetching certified skills: $e');
      return [];
    }
  }
}