import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class UserService {
  static final SupabaseClient _supabase = Supabase.instance.client;

  /// 1. ดึงข้อมูล User Profile
  static Future<Map<String, dynamic>?> getMyProfile(String userId) async {
    try {
      final response = await _supabase
          .from('users')
          .select('*')
          .eq('id', userId)
          .maybeSingle();
      return response;
    } catch (e) {
      debugPrint('Error fetching profile: $e');
      return null;
    }
  }

  /// 2. อัปเดตข้อมูลโปรไฟล์ผู้ใช้
  static Future<Map<String, dynamic>?> updateProfile({
    required String userId,
    String? fullName,
    String? targetRole,
    String? avatarUrl,
    String? bio,
    String? phone,
  }) async {
    try {
      final Map<String, dynamic> updates = {};
      if (fullName != null) updates['full_name'] = fullName;
      if (targetRole != null) updates['target_role'] = targetRole;
      if (avatarUrl != null) updates['avatar_url'] = avatarUrl;
      if (bio != null) updates['bio'] = bio;
      if (phone != null) updates['phone'] = phone;

      if (updates.isEmpty) return null;

      final response = await _supabase
          .from('users')
          .update(updates)
          .eq('id', userId)
          .select()
          .single();

      return response;
    } catch (e) {
      debugPrint('Error updating profile: $e');
      return null;
    }
  }

  /// 3. ดึงข้อมูลการตั้งค่าของผู้ใช้
  static Future<Map<String, dynamic>?> getSettings(String userId) async {
    try {
      final response = await _supabase
          .from('user_settings')
          .select('*')
          .eq('user_id', userId)
          .maybeSingle();

      return response;
    } catch (e) {
      debugPrint('Error fetching settings: $e');
      return null;
    }
  }

  /// 4. อัปเดตการตั้งค่าแบบครอบคลุม
  static Future<Map<String, dynamic>?> updateSettings({
    required String userId,
    bool? pushNotifications,
    bool? darkMode,
    String? language,
    bool? autoSave,
    bool? showLineNumbers,
    bool? soundEffects,
    String? fontSize,
  }) async {
    try {
      final Map<String, dynamic> updates = {
        'user_id': userId,
      };
      if (pushNotifications != null) updates['push_notifications'] = pushNotifications;
      if (darkMode != null) updates['dark_mode'] = darkMode;
      if (language != null) updates['language'] = language;
      if (autoSave != null) updates['auto_save'] = autoSave;
      if (showLineNumbers != null) updates['show_line_numbers'] = showLineNumbers;
      if (soundEffects != null) updates['sound_effects'] = soundEffects;
      if (fontSize != null) updates['font_size'] = fontSize;

      final response = await _supabase
          .from('user_settings')
          .upsert(updates)
          .select()
          .single();

      return response;
    } catch (e) {
      debugPrint('Error updating settings: $e');
      return null;
    }
  }

  /// 5. ล้างประวัติและความคืบหน้าของผู้ใช้ (สำหรับปุ่มรีเซ็ต)
  static Future<bool> resetUserProgress(String userId) async {
    try {
      await _supabase.from('user_progress').upsert({
        'user_id': userId,
        'total_xp': 20,
        'streak_days': 0,
        'run_count': 0,
        'updated_at': DateTime.now().toIso8601String(),
      });
      await _supabase.from('user_badges').delete().eq('user_id', userId);
      await _supabase.from('user_missions').delete().eq('user_id', userId);
      await _supabase.from('user_course_history').delete().eq('user_id', userId);
      return true;
    } catch (e) {
      debugPrint('Error resetting progress: $e');
      return false;
    }
  }
}