import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/user_guide.dart';

class GuideService {
  final SupabaseClient _supabase = Supabase.instance.client;

  /// 1. ดึงรายการบทความทั้งหมด หรือดึงตามหมวดหมู่
  Future<List<UserGuide>> listGuides({String? category}) async {
    try {
      var query = _supabase.from('user_guides').select('*');

      // ถ้ามีการส่ง Category มา ให้กรองข้อมูลตามหมวดหมู่
      if (category != null && category.isNotEmpty) {
        query = query.eq('category', category);
      }

      // เรียงลำดับตามวันที่สร้างล่าสุด (เนื่องจากใน Schema ไม่มี order_index)
      final response = await query.order('created_at', ascending: false);

      // Map ข้อมูล JSON เป็น List<UserGuide>
      return (response as List<dynamic>)
          .map((item) => UserGuide.fromJson(item as Map<String, dynamic>))
          .toList();
    } catch (e) {
      debugPrint('Error fetching guides: $e');
      return [];
    }
  }

  /// 2. ดึงรายละเอียดบทความ 1 เรื่อง และแอบบวกยอดวิวให้ด้วย
  Future<UserGuide> getGuide(int id) async {
    try {
      // ดึงข้อมูลบทความ
      final response = await _supabase
          .from('user_guides')
          .select('*')
          .eq('id', id)
          .single();
          
      final guide = UserGuide.fromJson(response);

      // (Optional) อัปเดตยอดวิวเพิ่มขึ้น 1
      await _supabase
          .from('user_guides')
          .update({'views_count': guide.viewsCount + 1})
          .eq('id', id);

      return guide;
    } catch (e) {
      debugPrint('Error fetching guide detail: $e');
      throw Exception('Failed to load guide details');
    }
  }
}