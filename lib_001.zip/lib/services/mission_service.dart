import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class MissionService {
  static final SupabaseClient _supabase = Supabase.instance.client;

  /// 1. ดึงรายการภารกิจทั้งหมด (ใช้ในหน้าเลือกด่าน)
  static Future<List<Map<String, dynamic>>> getMissions({String? track}) async {
    try {
      var query = _supabase.from('missions').select('*');
      
      // กรองตาม Track หากมีการส่งค่าเข้ามา
      if (track != null && track.isNotEmpty) {
        query = query.eq('track', track);
      }
      
      // เรียงตาม order_index เพื่อให้ด่านเรียงลำดับอย่างถูกต้อง
      final response = await query.order('order_index', ascending: true);
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      debugPrint('Error fetching missions: $e');
      return [];
    }
  }

  /// 2. ดึงสถานะภารกิจของผู้ใช้ (ว่าด่านไหนผ่านแล้ว หรือกำลังทำอยู่)
  static Future<List<Map<String, dynamic>>> getMyMissions(String userId) async {
    try {
      // ดึงข้อมูลการทำภารกิจ พร้อม Join ข้อมูลโจทย์ (missions) มาด้วย
      final response = await _supabase
          .from('user_missions')
          .select('*, missions(*)')
          .eq('user_id', userId);
          
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      debugPrint('Error fetching my missions: $e');
      return [];
    }
  }

  /// 3. ดึงรายละเอียดโจทย์ (โค้ดเริ่มต้น, คำอธิบาย ฯลฯ)
  static Future<Map<String, dynamic>?> getMissionDetail(String id) async {
    try {
      final response = await _supabase
          .from('missions')
          .select('*')
          .eq('id', id)
          .single(); // ดึงข้อมูลแค่ 1 แถว
          
      return response;
    } catch (e) {
      debugPrint('Error fetching mission detail: $e');
      return null;
    }
  }

  /// 4. เริ่มต้นภารกิจ (อัปเดตสถานะเป็น in_progress)
  static Future<void> startMission(String userId, String missionId) async {
    try {
      await _supabase.from('user_missions').upsert({
        'user_id': userId,
        'mission_id': missionId,
        'status': 'in_progress',
      });
    } catch (e) {
      debugPrint('Error starting mission: $e');
    }
  }

  /// 5. ส่งผลการรันโค้ดไปบันทึกลง Database
  static Future<bool> submitMission({
    required String userId,
    required String missionId,
    required String code,
    required bool passed,
  }) async {
    try {
      // เตรียมข้อมูลอัปเดต
      final Map<String, dynamic> updates = {
        'user_id': userId,
        'mission_id': missionId,
        'submitted_code': code,
        'status': passed ? 'completed' : 'in_progress',
      };

      // หากผ่านภารกิจ ให้บันทึกเวลาที่ทำสำเร็จด้วย
      if (passed) {
        updates['completed_at'] = DateTime.now().toIso8601String();
      }

      // ใช้ upsert เพื่อจัดการทั้งกรณีเพิ่มใหม่และอัปเดตข้อมูลเดิม (อ้างอิงจาก Primary Key คู่)
      await _supabase.from('user_missions').upsert(updates);
      
      return true; // คืนค่าสำเร็จ
    } catch (e) {
      debugPrint('Error submitting mission: $e');
      return false; // คืนค่าล้มเหลว
    }
  }
}