import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
// import '../models/course_model.dart'; // สามารถนำ Map ไปแปลงเป็น Model ต่อได้ในฝั่ง UI/Provider

class CourseService {
  static final SupabaseClient _supabase = Supabase.instance.client;

  /// 1. ดึงข้อมูลคอร์สทั้งหมดสำหรับแสดงบน Feed (หน้า Index)
  /// สามารถดึง max_potential_salary มาแสดงได้ทันทีตาม Schema ใหม่
  static Future<List<Map<String, dynamic>>> getCourses({String? difficultyLevel}) async {
    try {
      var query = _supabase.from('courses').select('''
        id,
        title,
        summary,
        cover_image_url,
        max_potential_salary,
        estimated_read_time_mins,
        difficulty_level,
        like_count,
        share_count
      ''');

      // รองรับการฟิลเตอร์ตามระดับความยาก (ถ้ามีการส่งพารามิเตอร์มา)
      if (difficultyLevel != null && difficultyLevel.isNotEmpty) {
        query = query.eq('difficulty_level', difficultyLevel);
      }

      final response = await query.order('created_at', ascending: false);
      
      // คืนค่าเป็น List ของ Map แล้วค่อยนำไป .map((json) => CourseModel.fromJson(json)) ใน UI
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      debugPrint('Error fetching courses: $e');
      return [];
    }
  }

  /// 2. ดึงรายละเอียดคอร์ส พร้อมกับบทเรียน (Course Lessons) แบบ Join Table
  static Future<Map<String, dynamic>?> getCourseDetail(String courseId) async {
    try {
      final response = await _supabase
          .from('courses')
          .select('''
            *,
            course_lessons (
              id,
              title,
              content,
              order_index,
              estimated_read_time_mins
            )
          ''')
          .eq('id', courseId)
          .single(); // ใช้ .single() เพราะค้นหาด้วย UUID จะได้ข้อมูลแค่ 1 แถวเสมอ

      return response;
    } catch (e) {
      debugPrint('Error fetching course detail: $e');
      return null;
    }
  }

  /// 3. จัดการบันทึกคอร์ส (Save/Unsave) ในตาราง saved_courses
  static Future<bool> toggleSaveCourse(String userId, String courseId, bool isAlreadySaved) async {
    try {
      if (isAlreadySaved) {
        // หากบันทึกไว้แล้ว -> ลบออก
        await _supabase
            .from('saved_courses')
            .delete()
            .match({'user_id': userId, 'course_id': courseId});
      } else {
        // หากยังไม่ได้บันทึก -> เพิ่มใหม่
        await _supabase
            .from('saved_courses')
            .insert({'user_id': userId, 'course_id': courseId});
      }
      return true;
    } catch (e) {
      debugPrint('Error toggling saved course: $e');
      return false;
    }
  }

  /// 4. (แถม) ดึงรายการคอร์สที่ผู้ใช้บันทึกไว้ สำหรับหน้า "Saved Courses" ใน Side Menu
  static Future<List<Map<String, dynamic>>> getSavedCourses(String userId) async {
    try {
      final response = await _supabase
          .from('saved_courses')
          .select('''
            saved_at,
            courses (*)
          ''')
          .eq('user_id', userId)
          .order('saved_at', ascending: false);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      debugPrint('Error fetching saved courses: $e');
      return [];
    }
  }
}