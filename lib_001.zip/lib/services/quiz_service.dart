import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class QuizService {
  static final SupabaseClient _supabase = Supabase.instance.client;

  /// 1. ดึงรายการแบบทดสอบทั้งหมดในคอร์สนั้น 
  /// (ใช้การระบุคอลัมน์ใน .select() เพื่อไม่ให้ดึงเฉลยมาฝั่ง Client ป้องกันการโกง)
  static Future<List<Map<String, dynamic>>> getCourseQuizzes(String courseId) async {
    try {
      final response = await _supabase
          .from('quizzes')
          .select('''
            id, 
            course_id, 
            lesson_order, 
            question, 
            option_1, 
            option_2, 
            option_3, 
            option_4
          ''')
          .eq('course_id', courseId)
          .order('lesson_order', ascending: true);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      debugPrint('Error fetching quizzes: $e');
      return [];
    }
  }

  /// 2. ตรวจคำตอบ (ดึงเฉลยจาก Database มาเทียบกับที่ผู้ใช้เลือก)
  static Future<Map<String, dynamic>?> answerQuiz(String quizId, int selectedIndex) async {
    try {
      // ดึงเฉพาะคอลัมน์เฉลย (correct_answer_index) และคำอธิบาย (explanation) จาก Database
      final response = await _supabase
          .from('quizzes')
          .select('correct_answer_index, explanation')
          .eq('id', quizId)
          .single();

      final int correctIndex = response['correct_answer_index'] as int;
      final bool isCorrect = correctIndex == selectedIndex;

      // คืนค่ารูปแบบเดียวกับที่ Backend ของคุณเคยส่งกลับมา
      return {
        'correct': isCorrect,
        'correct_answer_index': correctIndex,
        'explanation': response['explanation'],
      };
    } catch (e) {
      debugPrint('Error submitting quiz answer: $e');
      return null;
    }
  }
}