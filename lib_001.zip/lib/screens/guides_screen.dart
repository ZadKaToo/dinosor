import 'package:flutter/material.dart';
import '../services/guide_service.dart';
import '../models/user_guide.dart';

class GuidesScreen extends StatefulWidget {
  const GuidesScreen({super.key});

  @override
  State<GuidesScreen> createState() => _GuidesScreenState();
}

class _GuidesScreenState extends State<GuidesScreen> {
  late Future<List<UserGuide>> _future;
  final GuideService _guideService = GuideService();

  @override
  void initState() {
    super.initState();
    _future = _guideService.listGuides(); // เรียกใช้งานผ่าน Instance
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('คู่มือ')),
      body: FutureBuilder<List<UserGuide>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return Center(child: Text('Error: ${snap.error}'));
          }
          
          final guides = snap.data ?? [];
          if (guides.isEmpty) {
            return const Center(child: Text('ยังไม่มีบทความ'));
          }
          
          return ListView.builder(
            itemCount: guides.length,
            itemBuilder: (_, i) {
              final g = guides[i];
              return ListTile(
                leading: const Icon(Icons.menu_book, color: Colors.blueGrey),
                title: Text(g.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(
                  '${g.category.toUpperCase()} · ${g.readingTimeMins} นาที · ${g.viewsCount} views\n${g.summary}',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                isThreeLine: true,
                onTap: () async {
                  // แสดง Loading หรือไปยังหน้าใหม่เลย
                  try {
                    final detail = await _guideService.getGuide(g.id);
                    if (!context.mounted) return;
                    
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => GuideDetailScreen(guide: detail),
                      ),
                    );
                    
                    // รีเฟรชหน้าเก่าเพื่ออัปเดตยอดวิวตอนกลับมา
                    setState(() {
                      _future = _guideService.listGuides();
                    });
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('เกิดข้อผิดพลาดในการดึงข้อมูล')),
                    );
                  }
                },
              );
            },
          );
        },
      ),
    );
  }
}

class GuideDetailScreen extends StatelessWidget {
  final UserGuide guide;
  const GuideDetailScreen({super.key, required this.guide});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(guide.title)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              guide.title,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.timer, size: 16, color: Colors.grey[600]),
                const SizedBox(width: 4),
                Text('${guide.readingTimeMins} นาทีอ่าน'),
                const SizedBox(width: 16),
                Icon(Icons.visibility, size: 16, color: Colors.grey[600]),
                const SizedBox(width: 4),
                Text('${guide.viewsCount} ยอดเข้าชม'),
              ],
            ),
            const Divider(height: 32),
            // แสดงเนื้อหาเต็ม ถ้าไม่มีให้แสดง summary แทน
            Text(
              guide.content ?? guide.summary,
              style: const TextStyle(fontSize: 16, height: 1.6),
            ),
          ],
        ),
      ),
    );
  }
}