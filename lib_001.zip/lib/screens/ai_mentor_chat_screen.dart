import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/chat_message.dart';
import '../services/ai_mentor_service.dart';
import '../state/app_state.dart';

class AIMentorChatScreen extends StatefulWidget {
  const AIMentorChatScreen({super.key});

  @override
  State<AIMentorChatScreen> createState() => _AIMentorChatScreenState();
}

class _AIMentorChatScreenState extends State<AIMentorChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final AiMentorService _mentorService = AiMentorService();

  String? _sessionId;
  bool _isLoading = false;
  bool _isInitializing = true;

  final List<ChatMessage> _messages = [
    ChatMessage(
      text:
          'สวัสดีครับ! ผมคือ AI Mentor ผู้ช่วยวางแผนเส้นทางอาชีพ IT ของคุณ '
          'วันนี้อยากปรึกษาเรื่องทักษะ คอร์สเรียน หรือจำลองการสัมภาษณ์งานดีครับ?',
      isUser: false,
    ),
  ];

  final List<String> quickPrompts = [
    'เตรียมพอร์ตยังไงให้ได้งานแรก',
    'ไม่ได้จบตรงสายเริ่มยังไง',
    'จำลองสัมภาษณ์งานตำแหน่ง Junior',
    'ทักษะที่ตลาดต้องการมากที่สุด',
    'ฐานเงินเดือนเริ่มต้นแต่ละสาย',
  ];

  @override
  void initState() {
    super.initState();
    _initSession();
  }

  Future<void> _initSession() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) {
      setState(() => _isInitializing = false);
      return;
    }

    try {
      final sessionId = await _mentorService.getOrCreateSession(userId);
      final history = await _mentorService.getChatHistory(sessionId);

      if (!mounted) return;
      setState(() {
        _sessionId = sessionId;
        if (history.isNotEmpty) {
          _messages
            ..clear()
            ..addAll(history.map((m) => ChatMessage(
                  text: m['message_text']?.toString() ?? '',
                  isUser: m['sender_type'] == 'user',
                )));
        }
        _isInitializing = false;
      });
      _scrollToBottom();
    } catch (e) {
      debugPrint('Error initializing chat session: $e');
      if (mounted) setState(() => _isInitializing = false);
    }
  }

  Future<void> _sendMessage(String text) async {
    if (text.trim().isEmpty || _sessionId == null || _isLoading) return;

    setState(() {
      _messages.add(ChatMessage(text: text, isUser: true));
      _isLoading = true;
    });
    _controller.clear();
    _scrollToBottom();

    final reply = await _mentorService.sendMessage(sessionId: _sessionId!, message: text);

    if (!mounted) return;
    setState(() {
      _messages.add(ChatMessage(
        text: reply ?? 'ระบบขัดข้องชั่วคราว ลองใหม่อีกครั้งนะครับ',
        isUser: false,
      ));
      _isLoading = false;
    });
    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return Scaffold(
      backgroundColor: state.bgColor,
      appBar: AppBar(
        backgroundColor: state.sidebarColor,
        title: Row(
          children: [
            CircleAvatar(
              backgroundColor: state.accentColor,
              radius: 16,
              child: const Icon(Icons.smart_toy, size: 18, color: Colors.black),
            ),
            const SizedBox(width: 10),
            Text(
              'AI Mentor Assistant',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: state.textPrimary),
            ),
          ],
        ),
      ),
      body: _isInitializing
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.all(16),
                    itemCount: _messages.length,
                    itemBuilder: (context, index) {
                      final msg = _messages[index];
                      return Align(
                        alignment: msg.isUser ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 12),
                          padding: const EdgeInsets.all(12),
                          constraints:
                              BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
                          decoration: BoxDecoration(
                            color: msg.isUser ? state.accentColor : state.cardColor,
                            borderRadius: BorderRadius.circular(12),
                            border: msg.isUser ? null : Border.all(color: state.borderColor),
                          ),
                          child: MarkdownBody(
                            data: msg.text,
                            styleSheet: MarkdownStyleSheet.fromTheme(Theme.of(context)).copyWith(
                              p: TextStyle(
                                color: msg.isUser ? Colors.white : state.textPrimary,
                                fontSize: 13,
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                if (_isLoading)
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: CircularProgressIndicator(color: state.accentColor),
                  ),
                Container(
                  color: state.sidebarColor,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: quickPrompts.map((prompt) {
                        return Padding(
                          padding: const EdgeInsets.only(right: 8.0),
                          child: InkWell(
                            onTap: () => _sendMessage(prompt),
                            borderRadius: BorderRadius.circular(20),
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: state.cardAltColor,
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: state.borderColor),
                              ),
                              child: Text(
                                prompt,
                                style: TextStyle(color: state.accentColor, fontSize: 11),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(12),
                  color: state.sidebarColor,
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _controller,
                          style: TextStyle(color: state.textPrimary, fontSize: 13),
                          decoration: InputDecoration(
                            hintText: 'พิมพ์คำถามปรึกษา AI...',
                            hintStyle: TextStyle(color: state.textMuted),
                            border: InputBorder.none,
                          ),
                          onSubmitted: _sendMessage,
                        ),
                      ),
                      IconButton(
                        icon: Icon(Icons.send_rounded, color: state.accentColor),
                        onPressed: () => _sendMessage(_controller.text),
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}
