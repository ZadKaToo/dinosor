import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../constants/app_constants.dart';
import '../models/badge_def.dart';
import '../models/salary_tier.dart';
import '../models/run_history_entry.dart';

import '../services/user_service.dart';
import '../services/progress_service.dart';
import '../services/mission_service.dart';
import '../services/auth_service.dart';

class AppState extends ChangeNotifier {
  // ==========================================
  // PROGRESS & USER DATA
  // ==========================================
  int totalXP = 20; // ตรงกับ default ใน DB (user_progress.total_xp DEFAULT 20)
  int streakDays = 0;
  int missionsDone = 0;
  int runCount = 0;
  String selectedTrack = 'swe';
  String userId = '';
  String fullName = 'Guest';

  final Set<String> earnedBadges = {};
  final List<BadgeDef> pendingBadgeToasts = [];
  final Set<String> completedMissionIds = {};

  int get multiplier => streakDays >= 7 ? 3 : (streakDays >= 3 ? 2 : 1);

  SalaryTier get _tier {
    SalaryTier t = kSalaryTiers.first;
    for (final s in kSalaryTiers) {
      if (totalXP >= s.xp) {
        t = s;
      } else {
        break;
      }
    }
    return t;
  }

  int get currentSalary => _tier.salary;
  String get currentRole => _tier.role;
  int get level => (totalXP ~/ 100) + 1;
  int get xpIntoLevel => totalXP % 100;

  // ==========================================
  // INIT DATA (เรียกตอนเข้าแอปหลัง Login)
  // ==========================================
  Future<void> initializeUserData() async {
    final currentUserId = Supabase.instance.client.auth.currentUser?.id;
    if (currentUserId == null) return; // ยังไม่ได้ login จริงๆ ไม่ควรมาถึงจุดนี้
    userId = currentUserId;

    // getMyProfile()/getSettings() ดึงจากตาราง users / user_settings ตรงๆ ผ่าน
    // Supabase client — แทนที่ AuthService.me() ตัวเก่าที่ต่อกับ Express /api/auth/me
    final profileData = await UserService.getMyProfile(userId);
    final settingsData = await UserService.getSettings(userId);
    final progressData = await ProgressService.getMyProgress(userId);

    if (profileData != null) {
      fullName = profileData['full_name'] ?? 'Guest';
      selectedTrack = profileData['target_role'] ?? 'swe';
    }

    if (settingsData != null) {
      isLightTheme = !(settingsData['dark_mode'] ?? false);
      settingsNotifications = settingsData['push_notifications'] ?? true;
      // เฉพาะคอลัมน์ที่มีจริงใน user_settings เท่านั้น — ถ้ายังไม่ได้รัน migration
      // ที่เพิ่ม auto_save/show_line_numbers/sound_effects/font_size ค่าพวกนี้จะเป็น null
      // แล้วใช้ default local แทนโดยอัตโนมัติ (ไม่ error)
      settingsAutoSave = settingsData['auto_save'] ?? settingsAutoSave;
      settingsShowLineNumbers = settingsData['show_line_numbers'] ?? settingsShowLineNumbers;
      settingsSoundEffects = settingsData['sound_effects'] ?? settingsSoundEffects;
      settingsFontSize = settingsData['font_size'] ?? settingsFontSize;
    }

    if (progressData != null) {
      totalXP = progressData['total_xp'] ?? totalXP;
      streakDays = progressData['streak_days'] ?? streakDays;
      runCount = progressData['run_count'] ?? runCount;
      _applyBadgesFromProgressData(progressData);
    }

    final missionsData = await MissionService.getMyMissions(userId);
    completedMissionIds.clear();
    missionsDone = 0;
    for (final m in missionsData) {
      if (m['status'] == 'completed') {
        completedMissionIds.add(m['mission_id'].toString());
        missionsDone++;
      }
    }

    notifyListeners();
  }

  /// ProgressService.getMyProgress() คืนค่า badges ในคีย์ 'earned_badges' แบบ
  /// join ซ้อน (แต่ละแถวมี badges: {...} อยู่ข้างใน) ไม่ใช่ flat list แบบเก่า
  void _applyBadgesFromProgressData(Map<String, dynamic> progressData) {
    earnedBadges.clear();
    final List<dynamic> badges = progressData['earned_badges'] ?? [];
    for (final b in badges) {
      final badgeInfo = b['badges'];
      final id = badgeInfo is Map ? badgeInfo['id'] : null;
      if (id != null) earnedBadges.add(id.toString());
    }
  }

  // ==========================================
  // ACTIONS
  // ==========================================

  Future<void> addXP(int amount) async {
    if (userId.isEmpty) return;

    // Optimistic UI — คำนวณ multiplier ฝั่ง client เอง เพราะตอนนี้ addXp() ของ
    // Supabase service แค่บวกตัวเลขที่ส่งไปตรงๆ ไม่ได้คูณ multiplier ให้เหมือนตอน
    // เป็น Express backend ต้องส่งค่าที่คูณแล้ว (gained) ไปเป็น amount
    final gained = amount * multiplier;
    totalXP += gained;
    _checkBadgesLocal();
    notifyListeners();

    final result = await ProgressService.addXp(userId: userId, amount: gained);
    if (result != null) {
      totalXP = result['total_xp'] ?? totalXP;
      streakDays = result['streak_days'] ?? streakDays;
      runCount = result['run_count'] ?? runCount;
      notifyListeners();
    }
  }

  Future<void> incrementRunCount() async {
    if (userId.isEmpty) return;

    runCount++;
    _checkBadgesLocal();
    notifyListeners();

    final result = await ProgressService.incrementRunCount(userId);
    if (result != null) {
      runCount = result['run_count'] ?? runCount;
      notifyListeners();
    }
  }

  /// xp พารามิเตอร์นี้ใช้ทำ optimistic UI เท่านั้น — ไม่มี backend คอยกันการให้ XP
  /// ซ้ำแบบตอนเป็น Express backend อีกแล้ว (Supabase MissionService.submitMission
  /// แค่ upsert สถานะ ไม่ได้เช็ค/บวก XP ให้เอง) โค้ดนี้เลยเช็ค completedMissionIds
  /// ในเครื่องเองแทนเพื่อกันการกด submit ซ้ำแล้วได้ XP เพิ่ม
  Future<void> completeMissionById(String missionId, int xp) async {
    if (userId.isEmpty || completedMissionIds.contains(missionId)) return;

    completedMissionIds.add(missionId);
    missionsDone++;
    notifyListeners();

    await MissionService.submitMission(
      userId: userId,
      missionId: missionId,
      code: '# submitted code',
      passed: true,
    );

    // addXP() คูณ multiplier และ sync กับ backend ให้ในตัว
    await addXP(xp);
  }

  Future<void> selectTrack(String track) async {
    selectedTrack = track;
    notifyListeners();
    if (userId.isEmpty) return;
    await UserService.updateProfile(userId: userId, targetRole: track);
  }

  List<BadgeDef> _checkBadgesLocal() {
    final newlyEarned = <BadgeDef>[];
    void mark(String id) {
      if (!earnedBadges.contains(id)) {
        earnedBadges.add(id);
        try {
          final def = kBadges.firstWhere((b) => b.id == id);
          newlyEarned.add(def);
        } catch (e) {
          // ไม่พบ badge ใน local definition
        }
      }
    }

    if (runCount >= 1) mark('first_run');
    if (runCount >= 10) mark('coder');
    if (totalXP >= 40) mark('first_pass');
    if (totalXP >= 50) mark('xp50');
    if (totalXP >= 100) mark('xp100');
    if (totalXP >= 200) mark('xp200');
    if (missionsDone >= 1) mark('mission1');
    if (streakDays >= 3) mark('streak3');
    return newlyEarned;
  }

  List<BadgeDef> checkBadgesAndReturnNew() {
    final n = _checkBadgesLocal();
    if (n.isNotEmpty) notifyListeners();
    return n;
  }

  /// รีเซ็ต state ในเครื่องเท่านั้น — ถ้าต้องการรีเซ็ตข้อมูลจริงใน Supabase ด้วย
  /// ใช้ UserService.resetUserProgress(userId) ที่มีอยู่แล้ว (ยังไม่ได้เรียกในนี้
  /// เพราะเป็น action ทำลายข้อมูลถาวร ควรมีปุ่มยืนยันแยกต่างหากในหน้า Settings)
  Future<void> resetProgress() async {
    totalXP = 20;
    streakDays = 0;
    missionsDone = 0;
    runCount = 0;
    earnedBadges.clear();
    completedMissionIds.clear();
    runHistory.clear();
    completedCurriculum.clear();
    selectedTrack = 'swe';
    notifyListeners();
  }

  Future<void> logout() async {
    await AuthService.logout();
    userId = '';
    fullName = 'Guest';
    resetProgress();
  }

  // ==========================================
  // GLOBAL APP SETTINGS
  // ==========================================
  bool settingsAutoSave = true;
  bool settingsShowLineNumbers = true;
  String settingsFontSize = 'ปกติ';
  bool settingsNotifications = true;
  bool settingsSoundEffects = true;

  double get editorFontSize {
    switch (settingsFontSize) {
      case 'เล็ก': return 11;
      case 'ใหญ่': return 15;
      default: return 13;
    }
  }

  Future<void> _syncSettingsToBackend({
    bool? darkMode,
    bool? pushNotifications,
    bool? autoSave,
    bool? showLineNumbers,
    bool? soundEffects,
    String? fontSize,
  }) async {
    if (userId.isEmpty) return;
    await UserService.updateSettings(
      userId: userId,
      darkMode: darkMode,
      pushNotifications: pushNotifications,
      autoSave: autoSave,
      showLineNumbers: showLineNumbers,
      soundEffects: soundEffects,
      fontSize: fontSize,
    );
  }

  void updateAutoSave(bool v) {
    settingsAutoSave = v;
    notifyListeners();
    _syncSettingsToBackend(autoSave: v);
  }

  void updateShowLineNumbers(bool v) {
    settingsShowLineNumbers = v;
    notifyListeners();
    _syncSettingsToBackend(showLineNumbers: v);
  }

  void updateFontSize(String v) {
    settingsFontSize = v;
    notifyListeners();
    _syncSettingsToBackend(fontSize: v);
  }

  Future<void> updateNotifications(bool v) async {
    settingsNotifications = v;
    notifyListeners();
    await _syncSettingsToBackend(pushNotifications: v);
  }

  void updateSoundEffects(bool v) {
    settingsSoundEffects = v;
    notifyListeners();
    _syncSettingsToBackend(soundEffects: v);
  }

  // ==========================================
  // THEME
  // ==========================================
  bool isLightTheme = false;

  Future<void> toggleTheme(bool light) async {
    isLightTheme = light;
    notifyListeners();
    await _syncSettingsToBackend(darkMode: !light);
  }

  Color get bgColor => isLightTheme ? const Color(0xFFF3F8FF) : const Color(0xFF080C14);
  Color get sidebarColor => isLightTheme ? Colors.white : const Color(0xFF0A0F1A);
  Color get cardColor => isLightTheme ? const Color(0xFFEAF3FF) : const Color(0xFF0F172A);
  Color get cardAltColor => isLightTheme ? const Color(0xFFDCEBFF) : const Color(0xFF1E293B);
  Color get borderColor => isLightTheme ? const Color(0xFFBFDBFE) : const Color(0xFF1E293B);
  Color get borderColorSoft => isLightTheme ? const Color(0xFFDCEBFF) : const Color(0xFF334155);
  Color get textPrimary => isLightTheme ? const Color(0xFF0B1220) : Colors.white;
  Color get textSecondary => isLightTheme ? const Color(0xFF3B5177) : const Color(0xFF94A3B8);
  Color get textMuted => isLightTheme ? const Color(0xFF6B87B3) : const Color(0xFF64748B);
  Color get accentColor => isLightTheme ? const Color(0xFF2563EB) : const Color(0xFF10B981);

  ThemeData get themeData => isLightTheme
      ? ThemeData.light().copyWith(
          scaffoldBackgroundColor: const Color(0xFFF3F8FF),
          primaryColor: const Color(0xFF2563EB),
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF2563EB),
            brightness: Brightness.light,
          ),
          dialogBackgroundColor: Colors.white,
        )
      : ThemeData.dark().copyWith(
          scaffoldBackgroundColor: const Color(0xFF080C14),
          primaryColor: const Color(0xFF10B981),
        );

  final List<String> plannedCurriculum = [
    'Python Basics',
    'File I/O & Error Handling',
    'OOP & Classes',
    'API & HTTP Requests',
  ];
  final Set<String> completedCurriculum = {};

  void toggleCurriculumTopic(String topic) {
    if (completedCurriculum.contains(topic)) {
      completedCurriculum.remove(topic);
    } else {
      completedCurriculum.add(topic);
    }
    notifyListeners();
  }

  final List<RunHistoryEntry> runHistory = [];

  void addRunHistory(RunHistoryEntry entry) {
    runHistory.insert(0, entry);
    if (runHistory.length > 10) runHistory.removeLast();
    notifyListeners();
  }
}
