class UserGuide {
  final int id;
  final String title;
  final String summary;
  final String? content;
  final String category;
  final int readingTimeMins;
  final int viewsCount;

  UserGuide({
    required this.id,
    required this.title,
    required this.summary,
    this.content,
    required this.category,
    required this.readingTimeMins,
    required this.viewsCount,
  });

  // แปลงข้อมูลจาก Supabase (JSON) มาเป็น Object
  factory UserGuide.fromJson(Map<String, dynamic> json) {
    return UserGuide(
      id: json['id'] as int,
      title: json['title'] as String,
      summary: json['summary'] as String,
      content: json['content'] as String?,
      category: json['category'] as String? ?? 'general',
      readingTimeMins: json['reading_time_mins'] as int? ?? 5,
      viewsCount: json['views_count'] as int? ?? 0,
    );
  }
}