import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AiMentorService {
  static final SupabaseClient _supabase = Supabase.instance.client;

  /// 1. ดึงหรือสร้าง Session การแชทสำหรับผู้ใช้
  /// เพิ่มพารามิเตอร์ sessionType เพื่อรองรับทั้ง 'career_advice' และ 'mock_interview'
  static Future<String> getOrCreateSession({
    required String userId,
    String sessionType = 'career_advice', 
    String title = 'Career Mentoring',
  }) async {
    try {
      // ค้นหา Session ล่าสุดของผู้ใช้งาน โดยแยกตามประเภทการแชท
      final existingSession = await _supabase
          .from('chat_sessions')
          .select('id')
          .eq('user_id', userId)
          .eq('session_type', sessionType)
          .order('updated_at', ascending: false)
          .limit(1);

      if (existingSession.isNotEmpty) {
        return existingSession.first['id'] as String;
      }

      // ถ้ายังไม่มี Session สำหรับประเภทนี้ ให้สร้างใหม่
      final newSession = await _supabase
          .from('chat_sessions')
          .insert({
            'user_id': userId,
            'session_type': sessionType, // อ้างอิงตาม Check Constraint ใน Database
            'title': title,
          })
          .select('id')
          .single();

      return newSession['id'] as String;
    } catch (e) {
      debugPrint('Error getting or creating session: $e');
      rethrow;
    }
  }

  /// 2. ดึงประวัติแชทจาก Database เมื่อเปิดหน้าจอ
  static Future<List<Map<String, dynamic>>> getChatHistory(String sessionId) async {
    try {
      final response = await _supabase
          .from('chat_messages')
          .select('*')
          .eq('session_id', sessionId)
          .order('created_at', ascending: true); // เรียงตามเวลาจากเก่าไปใหม่

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      debugPrint('Error fetching chat history: $e');
      return [];
    }
  }

  /// 3. ส่งข้อความใหม่ไปหา AI และบันทึกลง Database
  static Future<String?> sendMessage({
    required String sessionId,
    required String message,
  }) async {
    try {
      // 3.1 บันทึกข้อความของ User ลง Database
      await _supabase.from('chat_messages').insert({
        'session_id': sessionId,
        'sender_type': 'user',
        'message_text': message,
      });

      // 3.2 เรียกใช้งาน AI Model 
      // ใน Supabase แนะนำให้ใช้ Edge Functions ในการเรียก AI (เช่น OpenAI/Gemini) 
      // เพื่อความปลอดภัยของ API Key (สมมติว่าสร้าง Edge Function ชื่อ 'ai_mentor')
      final response = await _supabase.functions.invoke(
        'ai_mentor',
        body: {
          'session_id': sessionId,
          'message': message,
        },
      );

      final data = response.data;
      final aiReply = data['reply']; // สมมติว่า Backend ส่งกลับมาใน Key ชื่อ 'reply'

      if (aiReply != null) {
        // 3.3 บันทึกข้อความที่ AI ตอบกลับลง Database
        await _supabase.from('chat_messages').insert({
          'session_id': sessionId,
          'sender_type': 'ai',
          'message_text': aiReply,
        });

        // 3.4 อัปเดตเวลาล่าสุดในตาราง chat_sessions ด้วย upsert หรือ update
        await _supabase.from('chat_sessions').update({
          'updated_at': DateTime.now().toIso8601String()
        }).eq('id', sessionId);
      }

      return aiReply;
    } catch (e) {
      debugPrint('Error calling AI Mentor: $e');
      return null;
    }
  }
}