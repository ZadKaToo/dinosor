import 'package0:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ProgressService {
  static final SupabaseClient _supabase = Supabase.instance.client;

  /// 1. ดึงข้อมูลความคืบหน้า (XP, Streak, Run Count และ Badges ทั้งหมด)
  static Future<Map<String, dynamic>?> getMyProgress(String userId) async {
    try {
      // ดึงข้อมูลหลักจาก user_progress
      final progressData = await _supabase
          .from('user_progress')
          .select('*')
          .eq('user_id', userId)
          .maybeSingle();

      // ดึงข้อมูล Badges ที่ผู้ใช้ได้รับพร้อมรายละเอียดของ Badge
      final badgesData = await _supabase
          .from('user_badges')
          .select('earned_at, badges(*)')
          .eq('user_id', userId);

      final Map<String, dynamic> result = Map<String, dynamic>.from(progressData ?? {
        'user_id': userId,
        'total_xp': 0,
        'streak_days': 0,
        'run_count': 0,
      });

      result['earned_badges'] = List<Map<String, dynamic>>.from(badgesData);
      return result;
    } catch (e) {
      debugPrint('Error fetching progress: $e');
      return null;
    }
  }

  /// 2. เพิ่ม XP ให้กับผู้ใช้งานในตาราง user_progress
  static Future<Map<String, dynamic>?> addXp({
    required String userId,
    required int amount,
  }) async {
    try {
      // ดึง XP ปัจจุบัน
      final currentData = await _supabase
          .from('user_progress')
          .select('total_xp')
          .eq('user_id', userId)
          .maybeSingle();

      final currentXp = (currentData?['total_xp'] as int?) ?? 0;
      final newXp = currentXp + amount;

      // อัปเดตข้อมูล XP ใหม่ด้วย upsert
      final updatedData = await _supabase
          .from('user_progress')
          .upsert({
            'user_id': userId,
            'total_xp': newXp,
            'updated_at': DateTime.now().toIso8601String(),
          })
          .select()
          .single();

      return updatedData;
    } catch (e) {
      debugPrint('Error adding XP: $e');
      return null;
    }
  }

  /// 3. เพิ่มจำนวนครั้งที่รันโค้ด (Increment Run Count)
  static Future<Map<String, dynamic>?> incrementRunCount(String userId) async {
    try {
      // ดึง run_count ปัจจุบัน
      final currentData = await _supabase
          .from('user_progress')
          .select('run_count')
          .eq('user_id', userId)
          .maybeSingle();

      final currentRunCount = (currentData?['run_count'] as int?) ?? 0;
      final newRunCount = currentRunCount + 1;

      // อัปเดตค่า run_count ใหม่
      final updatedData = await _supabase
          .from('user_progress')
          .upsert({
            'user_id': userId,
            'run_count': newRunCount,
            'updated_at': DateTime.now().toIso8601String(),
          })
          .select()
          .single();

      return updatedData;
    } catch (e) {
      debugPrint('Error incrementing run count: $e');
      return null;
    }
  }
}