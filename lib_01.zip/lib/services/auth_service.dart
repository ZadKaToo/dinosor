import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthService {
  static final SupabaseClient _supabase = Supabase.instance.client;

  /// เข้าสู่ระบบ
  static Future<String?> login(String email, String password) async {
    try {
      final response = await _supabase.auth.signInWithPassword(
        email: email,
        password: password,
      );
      if (response.session != null) return null; // สำเร็จ
      return 'ไม่พบ Session การเข้าใช้งาน';
    } on AuthException catch (e) {
      debugPrint('Login AuthException: ${e.message}');
      return 'อีเมลหรือรหัสผ่านไม่ถูกต้อง'; 
    } catch (e) {
      debugPrint('Login Unknown Error: $e');
      return 'เกิดข้อผิดพลาดในการเชื่อมต่อ: $e';
    }
  }

  /// สมัครสมาชิกและบันทึกลงตาราง public.users
  static Future<String?> register(String fullName, String email, String password) async {
    try {
      // 1. สร้างบัญชีในระบบ Authentication ของ Supabase
      final response = await _supabase.auth.signUp(
        email: email,
        password: password,
      );

      final user = response.user;
      if (user != null) {
        // 2. ทำการ Hash รหัสผ่านด้วย SHA-256
        final bytes = utf8.encode(password);
        final digest = sha256.convert(bytes);
        final hashedPassword = digest.toString();

        // 3. บันทึกข้อมูลลงตาราง "users" ตาม Schema
        // ใช้ upsert เพื่อป้องกัน Error กรณีสมัครซ้ำแล้วลบไปสมัครใหม่
        await _supabase.from('users').upsert({
          'id': user.id,                
          'email': email,
          'password_hash': hashedPassword,
          'full_name': fullName,
          'job_status': 'seeking', // ค่าเริ่มต้นตาม Schema
          'readiness_score': 0,
        });

        // 4. บันทึก Progress เริ่มต้น (ตาม Schema user_progress)
        await _supabase.from('user_progress').upsert({
          'user_id': user.id,
          'total_xp': 20,
          'streak_days': 0,
          'run_count': 0,
        });

        return null; // สำเร็จ ไม่มี Error
      }
      return 'ไม่สามารถสร้างบัญชีผู้ใช้ได้ โปรดลองอีกครั้ง';
    } on AuthException catch (e) {
      debugPrint('Register AuthException: ${e.message}');
      if (e.message.contains('User already registered')) {
        return 'อีเมลนี้มีผู้ใช้งานแล้ว';
      }
      return e.message;
    } catch (e) {
      debugPrint('Register Unknown Error: $e');
      return 'เกิดข้อผิดพลาดในการบันทึกข้อมูล: $e';
    }
  }

  /// ออกจากระบบ
  static Future<void> logout() async {
    try {
      await _supabase.auth.signOut();
    } catch (e) {
      debugPrint('Logout Error: $e');
    }
  }

  static Future<Map<String, dynamic>?> me() async {
    try {
      final token = await getToken();
      if (token == null) return null;

      final response = await http.get(
        Uri.parse('$baseUrl/me'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      }
      return null;
    } catch (e) {
      print('Error fetching profile: $e');
      return null;
    }
  }
}