import os
import uuid
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel
from google import genai
from google.genai import types
from supabase import create_client, Client

app = FastAPI()

# ตั้งค่า CORS อนุญาตให้เชื่อมต่อได้ทุก Domain
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 1. กำหนดค่า Gemini Client
gemini_client = genai.Client(api_key="AQ.Ab8RN6JYs69IfFYj0HUQoSRrRvc-UkACNjazN5NQXXWD8PWTIg")

# 2. กำหนดค่า Supabase Client
SUPABASE_URL = "https://fvccmpvjvahvoqglfizt.supabase.co"
SUPABASE_KEY = "sb_publishable_m0jTrkPVuOC0UDlaPkKMqA_q3OJQCVk"
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

system_prompt = """
คุณคือ AI Mentor ผู้เชี่ยวชาญด้านสายงาน IT
กฎเหล็กในการตอบ:
1. ตอบให้ตรงประเด็นและสั้นกระชับที่สุด ห้ามเกริ่นนำน้ำท่วมทุ่ง
2. คำถามทั่วไป/คำนวณง่ายๆ ให้ตอบเฉพาะคำตอบสั้นๆ ทันที
3. คำถามเกี่ยวกับสายงาน IT ให้สรุปเป็นหัวข้อสั้นๆ หรือ Bullet points ชัดเจน
"""

# โมเดลที่รองรับและพร้อมใช้งาน
# ปรับให้เรียกโมเดลความเร็วสูงก่อนเพื่อการตอบสนองที่รวดเร็ว
FALLBACK_MODELS = [
    "gemini-flash-lite-latest",
    "gemini-3.5-flash",
    "gemini-flash-latest",
    "gemini-3.7-flash"
]

class ChatRequest(BaseModel):
    message: str
    user_id: str | None = None

def get_valid_uuid(val: str | None) -> str | None:
    """ตรวจสอบและแปลงเป็น UUID ที่ถูกต้องสำหรับ Supabase"""
    if not val or val.lower() == "anonymous":
        return None
    try:
        return str(uuid.UUID(val))
    except ValueError:
        return None

@app.get("/", response_class=HTMLResponse)
async def serve_index():
    file_path = os.path.join(os.path.dirname(__file__), "index.html")
    if os.path.exists(file_path):
        return FileResponse(file_path)
    return "<h1>AI Mentor API is working!</h1>"

@app.post("/api/mentor")
async def ai_mentor(request: ChatRequest):
    last_error = ""
    reply_text = ""

    # 1. ดึงคำตอบจาก Gemini AI
    for model_name in FALLBACK_MODELS:
        try:
            response = gemini_client.models.generate_content(
                model=model_name,
                contents=request.message,
                config=types.GenerateContentConfig(
                    system_instruction=system_prompt,
                    temperature=0.2,
                ),
            )
            reply_text = response.text
            break
        except Exception as e:
            last_error = str(e)
            print(f"⚠️ โมเดล {model_name} ไม่ว่าง กำลังลองตัวถัดไป... ({e})")
            continue
            
    if not reply_text:
        return {"reply": f"เกิดข้อผิดพลาดในการประมวลผล: {last_error}"}

    # 2. บันทึกประวัติบทสนทนาลง Supabase
    try:
        valid_user_id = get_valid_uuid(request.user_id)
        
        supabase.table("chat_history").insert({
            "user_id": valid_user_id,
            "user_message": request.message,
            "bot_reply": reply_text
        }).execute()
    except Exception as db_err:
        print(f"⚠️ บันทึกลง Supabase ไม่สำเร็จ: {db_err}")

    return {"reply": reply_text}