from google import genai

client = genai.Client(api_key="AQ.Ab8RN6JYs69IfFYj0HUQoSRrRvc-UkACNjazN5NQXXWD8PWTIg")

print("--- รายชื่อโมเดลที่ใช้ได้ ---")
try:
    for model in client.models.list():
        # แสดงเฉพาะโมเดลที่รองรับการ generateContent
        if "generateContent" in model.supported_actions:
            print(model.name)
except Exception as e:
    print(f"Error: {e}")