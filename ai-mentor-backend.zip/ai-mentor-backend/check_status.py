import urllib.request
import json

def check_services():
    print("=" * 45)
    print("🔍 กำลังตรวจสอบสถานะการเปิดเซิร์ฟเวอร์...")
    print("=" * 45)

    # 1. ตรวจสอบ Backend ในเครื่อง (Port 8000)
    try:
        req = urllib.request.Request("http://127.0.0.1:8000/")
        with urllib.request.urlopen(req, timeout=3) as res:
            if res.status in [200, 404, 405]:
                print("✅ 1. Backend (FastAPI - Port 8000): กำลังทำงานปกติ")
    except Exception:
        print("❌ 1. Backend (FastAPI - Port 8000): ไม่ทำงาน (ลืมรัน uvicorn หรือเซิร์ฟเวอร์ดับ)")

    # 2. ตรวจสอบ LocalTunnel (ใส่ URL ปัจจุบัน)
    tunnel_url = "https://ten-jars-lie.loca.lt/api/mentor"
    try:
        req = urllib.request.Request(
            tunnel_url,
            headers={"Bypass-Tunnel-Reminder": "true", "User-Agent": "StatusChecker"}
        )
        with urllib.request.urlopen(req, timeout=5) as res:
            print(f"✅ 2. LocalTunnel ({tunnel_url}): เชื่อมต่อออนไลน์สำเร็จ")
    except Exception as e:
        print(f"❌ 2. LocalTunnel ({tunnel_url}): ไม่สามารถเชื่อมต่อได้ (URL ผิด หรือหลุดการเชื่อมต่อ)")

    print("=" * 45)

if __name__ == "__main__":
    check_services()