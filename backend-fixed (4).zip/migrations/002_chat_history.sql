-- ========================================================
-- Adds the chat_history table used by chatController.js
-- (POST /api/mentor and GET /api/mentor/history) — this table
-- was referenced in the code but never defined in the schema,
-- so every chat message insert was failing with a DB error.
-- ========================================================

CREATE TABLE IF NOT EXISTS chat_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    user_message TEXT NOT NULL,
    bot_reply TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_chat_history_user_id ON chat_history(user_id, created_at);
