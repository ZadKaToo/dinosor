const express = require('express');
const auth = require('../middleware/auth');
const { sendMentorMessage, getChatHistory } = require('../controllers/chatController');

const router = express.Router();

router.use(auth);

router.post('/', sendMentorMessage);
router.get('/history', getChatHistory);

module.exports = router;

// NOTE: not currently mounted — app.js registers these same handlers
// directly at POST /api/mentor and GET /api/mentor/history for backward
// compatibility with the Flutter client. If you'd rather mount this router
// instead, replace those two lines in app.js with:
//   app.use('/api/mentor', require('./routes/chatRoutes'));
