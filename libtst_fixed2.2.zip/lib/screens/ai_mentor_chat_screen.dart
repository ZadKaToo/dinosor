import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/app_state.dart';
import '../models/chat_message.dart';
import '../services/ai_mentor_service.dart';
import '../widgets/google_fonts_shim.dart';
import '../widgets/typing_dot.dart';

class AIMentorChatScreen extends StatefulWidget {
  const AIMentorChatScreen({super.key});

  @override
  State<AIMentorChatScreen> createState() => _AIMentorChatScreenState();
}

class _AIMentorChatScreenState extends State<AIMentorChatScreen> {
  final AiMentorService _service = AiMentorService();
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  String? _sessionId;
  final List<ChatMessage> _messages = [];
  bool _isLoadingHistory = true;
  bool _isSending = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _initSession());
  }

  Future<void> _initSession() async {
    setState(() {
      _isLoadingHistory = true;
      _errorMessage = null;
    });

    final userId = context.read<AppState>().userId;
    if (userId.isEmpty) {
      setState(() {
        _isLoadingHistory = false;
        _errorMessage = 'ยังไม่ได้เข้าสู่ระบบ กรุณาล็อกอินก่อนใช้งาน AI Mentor';
      });
      return;
    }

    try {
      final sessionId = await _service.getOrCreateSession(userId);
      final history = await _service.getChatHistory(sessionId);

      setState(() {
        _sessionId = sessionId;
        _messages.clear();
        _messages.addAll(history.map((m) => ChatMessage(
              text: m['message_text'] ?? '',
              isUser: m['sender_type'] == 'user',
            )));
        _isLoadingHistory = false;
      });
      _scrollToBottom();
    } catch (e) {
      debugPrint('AIMentorChatScreen _initSession error: $e');
      setState(() {
        _isLoadingHistory = false;
        _errorMessage = 'เชื่อมต่อไม่สำเร็จ: $e';
      });
    }
  }

  Future<void> _sendMessage() async {
    final text = _controller.text.trim();
    if (text.isEmpty || _isSending) return;

    if (_sessionId == null) {
      setState(() {
        _errorMessage = 'ยังไม่มี session แชท ลองกด "ลองใหม่" ด้านบนก่อนส่งข้อความ';
      });
      return;
    }

    setState(() {
      _messages.add(ChatMessage(text: text, isUser: true));
      _isSending = true;
      _controller.clear();
      _errorMessage = null;
    });
    _scrollToBottom();

    try {
      final reply = await _service.sendMessage(sessionId: _sessionId!, message: text);

      setState(() {
        _isSending = false;
        if (reply != null) {
          _messages.add(ChatMessage(text: reply, isUser: false));
        } else {
          // sendMessage คืนค่า null แปลว่ามี error ฝั่ง backend (ดู debug console)
          // สาเหตุที่พบบ่อยที่สุด: ยังไม่ได้ deploy Supabase Edge Function ชื่อ 'ai_mentor'
          _errorMessage = 'ส่งข้อความไม่สำเร็จ (Edge Function "ai_mentor" อาจยังไม่ได้ deploy หรือ error)';
        }
      });
    } catch (e) {
      debugPrint('AIMentorChatScreen _sendMessage error: $e');
      setState(() {
        _isSending = false;
        _errorMessage = 'ส่งข้อความไม่สำเร็จ: $e';
      });
    }
    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return Container(
      color: state.bgColor,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            decoration: BoxDecoration(
              color: state.sidebarColor,
              border: Border(bottom: BorderSide(color: state.borderColor)),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  backgroundColor: state.accentColor,
                  child: const Icon(Icons.smart_toy, color: Colors.white, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'AI Career Mentor',
                    style: GoogleFonts.prompt(
                      color: state.textPrimary,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                if (_errorMessage != null)
                  TextButton.icon(
                    onPressed: _initSession,
                    icon: Icon(Icons.refresh, color: state.accentColor, size: 18),
                    label: Text('ลองใหม่', style: GoogleFonts.prompt(color: state.accentColor, fontSize: 13)),
                  ),
              ],
            ),
          ),
          if (_errorMessage != null)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              color: const Color(0xFFDC2626).withOpacity(0.12),
              child: Text(
                _errorMessage!,
                style: GoogleFonts.prompt(color: const Color(0xFFDC2626), fontSize: 12),
              ),
            ),
          Expanded(
            child: _isLoadingHistory
                ? Center(child: CircularProgressIndicator(color: state.accentColor))
                : _messages.isEmpty
                    ? Center(
                        child: Text(
                          'เริ่มพูดคุยกับ AI Mentor ได้เลยค่ะ',
                          style: GoogleFonts.prompt(color: state.textMuted),
                        ),
                      )
                    : ListView.builder(
                        controller: _scrollController,
                        padding: const EdgeInsets.all(16),
                        itemCount: _messages.length + (_isSending ? 1 : 0),
                        itemBuilder: (context, index) {
                          if (index == _messages.length) {
                            return _buildTypingIndicator(state);
                          }
                          final msg = _messages[index];
                          return _buildBubble(state, msg);
                        },
                      ),
          ),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: state.sidebarColor,
              border: Border(top: BorderSide(color: state.borderColor)),
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    style: GoogleFonts.prompt(color: state.textPrimary, fontSize: 14),
                    decoration: InputDecoration(
                      hintText: 'พิมพ์ข้อความ...',
                      hintStyle: GoogleFonts.prompt(color: state.textMuted, fontSize: 14),
                      filled: true,
                      fillColor: state.cardColor,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: BorderSide.none,
                      ),
                    ),
                    onSubmitted: (_) => _sendMessage(),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  onPressed: _isSending ? null : _sendMessage,
                  icon: Icon(Icons.send_rounded, color: state.accentColor),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBubble(AppState state, ChatMessage msg) {
    return Align(
      alignment: msg.isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints: const BoxConstraints(maxWidth: 320),
        decoration: BoxDecoration(
          color: msg.isUser ? state.accentColor : state.cardColor,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Text(
          msg.text,
          style: GoogleFonts.prompt(
            color: msg.isUser ? Colors.white : state.textPrimary,
            fontSize: 14,
          ),
        ),
      ),
    );
  }

  Widget _buildTypingIndicator(AppState state) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: state.cardColor,
          borderRadius: BorderRadius.circular(16),
        ),
        child: const Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            TypingDot(delay: 0),
            SizedBox(width: 4),
            TypingDot(delay: 150),
            SizedBox(width: 4),
            TypingDot(delay: 300),
          ],
        ),
      ),
    );
  }
}
