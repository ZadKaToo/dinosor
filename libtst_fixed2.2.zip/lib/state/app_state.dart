import 'package:flutter/material.dart';
import '../constants/app_constants.dart';
import '../models/badge_def.dart';
import '../models/salary_tier.dart';
import '../models/run_history_entry.dart';

import '../services/user_service.dart';
import '../services/progress_service.dart';
import '../services/mission_service.dart';
import '../services/auth_service.dart';

class AppState extends ChangeNotifier {
  // ==========================================
  // PROGRESS & USER DATA
  // ==========================================
  int totalXP = 20; // ตรงกับ default ใน DB (user_progress.total_xp DEFAULT 20)
  int streakDays = 0;
  int missionsDone = 0;
  int runCount = 0;
  String selectedTrack = 'swe';
  String userId = '';
  String fullName = 'Guest';

  final Set<String> earnedBadges = {};
  final List<BadgeDef> pendingBadgeToasts = [];
  final Set<String> completedMissionIds = {};

  int get multiplier => streakDays >= 7 ? 3 : (streakDays >= 3 ? 2 : 1);

  SalaryTier get _tier {
    SalaryTier t = kSalaryTiers.first;
    for (final s in kSalaryTiers) {
      if (totalXP >= s.xp) {
        t = s;
      } else {
        break;
      }
    }
    return t;
  }

  int get currentSalary => _tier.salary;
  String get currentRole => _tier.role;
  int get level => (totalXP ~/ 100) + 1;
  int get xpIntoLevel => totalXP % 100;

  // ==========================================
  // INIT DATA (เรียกตอนเข้าแอปหลัง Login)
  // ==========================================
  Future<void> initializeUserData() async {
    // AuthService.me() ต่อ /api/auth/me ที่ join user_progress + user_settings มาแล้ว
    // (ต้องเพิ่มเมธอด me() ใน AuthService ของคุณ — ดูตัวอย่างท้ายข้อความ)
    final profileData = await AuthService.me();

    if (profileData != null) {
      userId = profileData['id'] ?? '';
      fullName = profileData['full_name'] ?? 'Guest';
      selectedTrack = profileData['target_role'] ?? 'swe';
      isLightTheme = !(profileData['dark_mode'] ?? false);
    }

    // ยังเรียก getMyProgress() แยก เพราะมี badges ติดมาด้วย ซึ่ง /api/auth/me ไม่ได้ join
    final progressData = await ProgressService.getMyProgress(userId);

    if (progressData != null) {
      totalXP = progressData['total_xp'] ?? totalXP;
      streakDays = progressData['streak_days'] ?? streakDays;
      runCount = progressData['run_count'] ?? runCount;

      earnedBadges.clear();
      final List<dynamic> badges = progressData['earned_badges'] ?? [];
      for (var b in badges) {
        if (b['badges'] != null && b['badges']['id'] != null) earnedBadges.add(b['badges']['id'].toString());
      }
    }

    final missionsData = await MissionService.getMyMissions(userId);
    completedMissionIds.clear();
    missionsDone = 0;
    for (var m in missionsData) {
      if (m['status'] == 'completed') {
        completedMissionIds.add(m['mission_id'].toString());
        missionsDone++;
      }
    }

    notifyListeners();
  }

  // ==========================================
  // ACTIONS
  // ==========================================

  Future<void> addXP(int amount) async {
    final gained = amount * multiplier;
    totalXP += gained;
    _checkBadgesLocal();
    notifyListeners();

    final result = await ProgressService.addXp(userId: userId, amount: amount);
    if (result != null) {
      totalXP = result['total_xp'] ?? totalXP;
      streakDays = result['streak_days'] ?? streakDays;
      runCount = result['run_count'] ?? runCount;
      await _refreshBadges();
      notifyListeners();
    }
  }

  Future<void> incrementRunCount() async {
    runCount++;
    _checkBadgesLocal();
    notifyListeners();

    final result = await ProgressService.incrementRunCount(userId);
    if (result != null) {
      runCount = result['run_count'] ?? runCount;
      await _refreshBadges();
      notifyListeners();
    }
  }

  /// xp พารามิเตอร์นี้ใช้แค่ทำ optimistic UI ก่อน backend ตอบกลับเท่านั้น
  /// จำนวน XP จริงถูกกำหนดที่ backend (ตาราง missions.xp_reward) และกันการให้ซ้ำถ้า
  /// submit มากกว่า 1 ครั้งให้อัตโนมัติแล้ว — ห้ามเรียก addXP() ซ้ำในนี้อีก
  Future<void> completeMissionById(String missionId, int xp) async {
    if (completedMissionIds.contains(missionId)) return;

    // Optimistic UI
    completedMissionIds.add(missionId);
    missionsDone++;
    totalXP += xp * multiplier;
    _checkBadgesLocal();
    notifyListeners();

    await MissionService.submitMission(
      userId: userId,
      missionId: missionId,
      code: '# submitted code',
      passed: true,
    );

    // ดึงค่าจริงจาก backend มาทับค่า optimistic เสมอ กัน XP เพี้ยน
    final progressData = await ProgressService.getMyProgress(userId);
    if (progressData != null) {
      totalXP = progressData['total_xp'] ?? totalXP;
      streakDays = progressData['streak_days'] ?? streakDays;
      runCount = progressData['run_count'] ?? runCount;
      earnedBadges.clear();
      final List<dynamic> badges = progressData['earned_badges'] ?? [];
      for (var b in badges) {
        if (b['badges'] != null && b['badges']['id'] != null) earnedBadges.add(b['badges']['id'].toString());
      }
    }
    notifyListeners();
  }

  Future<void> _refreshBadges() async {
    final progressData = await ProgressService.getMyProgress(userId);
    if (progressData == null) return;
    final List<dynamic> badges = progressData['earned_badges'] ?? [];
    for (var b in badges) {
      if (b['badges'] != null && b['badges']['id'] != null) earnedBadges.add(b['badges']['id'].toString());
    }
  }

  Future<void> selectTrack(String track) async {
    selectedTrack = track;
    notifyListeners();
    await UserService.updateProfile(userId: userId, targetRole: track);
  }

  List<BadgeDef> _checkBadgesLocal() {
    final newlyEarned = <BadgeDef>[];
    void mark(String id) {
      if (!earnedBadges.contains(id)) {
        earnedBadges.add(id);
        try {
          final def = kBadges.firstWhere((b) => b.id == id);
          newlyEarned.add(def);
        } catch (e) {
          // ไม่พบ badge ใน local definition
        }
      }
    }

    if (runCount >= 1) mark('first_run');
    if (runCount >= 10) mark('coder');
    if (totalXP >= 40) mark('first_pass');
    if (totalXP >= 50) mark('xp50');
    if (totalXP >= 100) mark('xp100');
    if (totalXP >= 200) mark('xp200');
    if (missionsDone >= 1) mark('mission1');
    if (streakDays >= 3) mark('streak3');
    return newlyEarned;
  }

  List<BadgeDef> checkBadgesAndReturnNew() {
    final n = _checkBadgesLocal();
    if (n.isNotEmpty) notifyListeners();
    return n;
  }

  /// รีเซ็ต state ในเครื่อง — ยังไม่มี endpoint ฝั่ง backend สำหรับรีเซ็ตจริงใน DB
  /// (ถ้าต้องการให้ลบ/รีเซ็ตข้อมูลใน user_progress จริงๆ ต้องเพิ่ม
  /// POST /api/progress/me/reset ฝั่ง backend ก่อน — บอกได้ถ้าอยากให้เพิ่ม)
  Future<void> resetProgress() async {
    totalXP = 20;
    streakDays = 0;
    missionsDone = 0;
    runCount = 0;
    earnedBadges.clear();
    completedMissionIds.clear();
    runHistory.clear();
    completedCurriculum.clear();
    selectedTrack = 'swe';
    notifyListeners();
  }

  Future<void> logout() async {
    await AuthService.logout();
    resetProgress();
  }

  // ==========================================
  // GLOBAL APP SETTINGS
  // ==========================================
  bool settingsAutoSave = true;
  bool settingsShowLineNumbers = true;
  String settingsFontSize = 'ปกติ';
  bool settingsNotifications = true;
  bool settingsSoundEffects = true;

  double get editorFontSize {
    switch (settingsFontSize) {
      case 'เล็ก': return 11;
      case 'ใหญ่': return 15;
      default: return 13;
    }
  }

  /// เก็บได้แค่ dark_mode / push_notifications ตอนนี้ เพราะ user_settings ใน DB
  /// มีแค่ 2 คอลัมน์นี้ (+ language) — autoSave/showLineNumbers/soundEffects/fontSize
  /// ยังเป็น local-only ถ้าอยากให้เก็บถาวรด้วย ต้องเพิ่มคอลัมน์ในตารางก่อน (บอกได้)
  Future<void> _syncSettingsToBackend({bool? darkMode, bool? pushNotifications}) async {
    await UserService.updateSettings(userId: userId, darkMode: darkMode, pushNotifications: pushNotifications);
  }

  void updateAutoSave(bool v) {
    settingsAutoSave = v; // local-only
    notifyListeners();
  }

  void updateShowLineNumbers(bool v) {
    settingsShowLineNumbers = v; // local-only
    notifyListeners();
  }

  void updateFontSize(String v) {
    settingsFontSize = v; // local-only
    notifyListeners();
  }

  Future<void> updateNotifications(bool v) async {
    settingsNotifications = v;
    notifyListeners();
    await _syncSettingsToBackend(pushNotifications: v);
  }

  void updateSoundEffects(bool v) {
    settingsSoundEffects = v; // local-only
    notifyListeners();
  }

  // ==========================================
  // THEME
  // ==========================================
  bool isLightTheme = false;

  Future<void> toggleTheme(bool light) async {
    isLightTheme = light;
    notifyListeners();
    await _syncSettingsToBackend(darkMode: !light);
  }

  Color get bgColor => isLightTheme ? const Color(0xFFF3F8FF) : const Color(0xFF080C14);
  Color get sidebarColor => isLightTheme ? Colors.white : const Color(0xFF0A0F1A);
  Color get cardColor => isLightTheme ? const Color(0xFFEAF3FF) : const Color(0xFF0F172A);
  Color get cardAltColor => isLightTheme ? const Color(0xFFDCEBFF) : const Color(0xFF1E293B);
  Color get borderColor => isLightTheme ? const Color(0xFFBFDBFE) : const Color(0xFF1E293B);
  Color get borderColorSoft => isLightTheme ? const Color(0xFFDCEBFF) : const Color(0xFF334155);
  Color get textPrimary => isLightTheme ? const Color(0xFF0B1220) : Colors.white;
  Color get textSecondary => isLightTheme ? const Color(0xFF3B5177) : const Color(0xFF94A3B8);
  Color get textMuted => isLightTheme ? const Color(0xFF6B87B3) : const Color(0xFF64748B);
  Color get accentColor => isLightTheme ? const Color(0xFF2563EB) : const Color(0xFF10B981);

  ThemeData get themeData => isLightTheme
      ? ThemeData.light().copyWith(
          scaffoldBackgroundColor: const Color(0xFFF3F8FF),
          primaryColor: const Color(0xFF2563EB),
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF2563EB),
            brightness: Brightness.light,
          ),
          dialogBackgroundColor: Colors.white,
        )
      : ThemeData.dark().copyWith(
          scaffoldBackgroundColor: const Color(0xFF080C14),
          primaryColor: const Color(0xFF10B981),
        );

  final List<String> plannedCurriculum = [
    'Python Basics',
    'File I/O & Error Handling',
    'OOP & Classes',
    'API & HTTP Requests',
  ];
  final Set<String> completedCurriculum = {};

  void toggleCurriculumTopic(String topic) {
    if (completedCurriculum.contains(topic)) {
      completedCurriculum.remove(topic);
    } else {
      completedCurriculum.add(topic);
    }
    notifyListeners();
  }

  final List<RunHistoryEntry> runHistory = [];

  void addRunHistory(RunHistoryEntry entry) {
    runHistory.insert(0, entry);
    if (runHistory.length > 10) runHistory.removeLast();
    notifyListeners();
  }
}